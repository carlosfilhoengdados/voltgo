import { 
  User, InsertUser, 
  ChargingStation, InsertChargingStation, 
  Connector, InsertConnector,
  Review, InsertReview,
  ChargingSession, InsertChargingSession,
  FavoriteStation, InsertFavoriteStation
} from "@shared/schema";

// Storage interface with all CRUD operations needed
export interface IStorage {
  // User operations
  getUser(id: number): Promise<User | undefined>;
  getUserByUsername(username: string): Promise<User | undefined>;
  createUser(user: InsertUser): Promise<User>;
  updateUserPoints(userId: number, points: number): Promise<User | undefined>;
  
  // Charging station operations
  getAllChargingStations(): Promise<ChargingStation[]>;
  getChargingStation(id: number): Promise<ChargingStation | undefined>;
  getNearbyChargingStations(latitude: number, longitude: number, radius: number): Promise<ChargingStation[]>;
  createChargingStation(station: InsertChargingStation): Promise<ChargingStation>;
  updateChargingStation(id: number, station: Partial<ChargingStation>): Promise<ChargingStation | undefined>;
  
  // Connector operations
  getConnectorsByStationId(stationId: number): Promise<Connector[]>;
  createConnector(connector: InsertConnector): Promise<Connector>;
  
  // Review operations
  getReviewsByStationId(stationId: number): Promise<Review[]>;
  createReview(review: InsertReview): Promise<Review>;
  
  // Charging session operations
  getChargingSessionsByUserId(userId: number): Promise<ChargingSession[]>;
  getChargingSessionsByStationId(stationId: number): Promise<ChargingSession[]>;
  createChargingSession(session: InsertChargingSession): Promise<ChargingSession>;
  updateChargingSession(id: number, session: Partial<ChargingSession>): Promise<ChargingSession | undefined>;
  
  // Favorite stations operations
  getFavoriteStationsByUserId(userId: number): Promise<FavoriteStation[]>;
  createFavoriteStation(favorite: InsertFavoriteStation): Promise<FavoriteStation>;
  deleteFavoriteStation(userId: number, stationId: number): Promise<boolean>;
}

export class MemStorage implements IStorage {
  private users: Map<number, User>;
  private chargingStations: Map<number, ChargingStation>;
  private connectors: Map<number, Connector>;
  private reviews: Map<number, Review>;
  private chargingSessions: Map<number, ChargingSession>;
  private favoriteStations: Map<number, FavoriteStation>;
  
  private userId: number = 1;
  private stationId: number = 1;
  private connectorId: number = 1;
  private reviewId: number = 1;
  private sessionId: number = 1;
  private favoriteId: number = 1;
  
  constructor() {
    this.users = new Map();
    this.chargingStations = new Map();
    this.connectors = new Map();
    this.reviews = new Map();
    this.chargingSessions = new Map();
    this.favoriteStations = new Map();
    
    // Initialize with sample data
    this.initSampleData();
  }
  
  private initSampleData() {
    // Sample charging stations
    this.createChargingStation({
      name: "Shopping Ibirapuera",
      address: "Av. Ibirapuera, 3103 - São Paulo",
      latitude: -23.6102,
      longitude: -46.6676,
      image: "https://images.unsplash.com/photo-1593941707882-a156679de2f5",
      stationType: "Shopping",
      power: 50,
      price: 2.30,
      totalSpots: 3,
      availableSpots: 2,
      status: "Available",
      pointsReward: 150,
      openingTime: "7h às 22h (todos os dias)",
      hasCoffee: true,
      hasWifi: true,
      hasRestrooms: true,
      hasShops: true,
      hasRestaurants: true
    });
    
    this.createChargingStation({
      name: "Supercarregador Vila Olímpia",
      address: "R. Funchal, 418 - Vila Olímpia",
      latitude: -23.5958,
      longitude: -46.6867,
      image: "https://images.unsplash.com/photo-1608543532637-f8c8a2682a03",
      stationType: "Supercarregador",
      power: 150,
      price: 3.50,
      totalSpots: 2,
      availableSpots: 0,
      status: "Occupied",
      pointsReward: 230,
      openingTime: "24h",
      hasWifi: true,
      hasRestrooms: true
    });
    
    this.createChargingStation({
      name: "Posto Ipiranga EletroPoint",
      address: "Av. Rebouças, 2875 - Pinheiros",
      latitude: -23.5673,
      longitude: -46.6730,
      image: "https://images.unsplash.com/photo-1677098077185-5438068c2ae8",
      stationType: "Café",
      power: 22,
      price: 2.00,
      totalSpots: 4,
      availableSpots: 3,
      status: "Available",
      pointsReward: 100,
      openingTime: "6h às 23h (todos os dias)",
      hasCoffee: true,
      hasWifi: true,
      hasRestrooms: true
    });
    
    this.createChargingStation({
      name: "Corporate Tower Faria Lima",
      address: "Av. Faria Lima, 3477 - Itaim Bibi",
      latitude: -23.5861,
      longitude: -46.6824,
      image: "https://images.unsplash.com/photo-1601362840469-51e4d8d58785",
      stationType: "Corporativo",
      power: 11,
      price: 1.80,
      totalSpots: 6,
      availableSpots: 5,
      status: "Available",
      pointsReward: 80,
      openingTime: "8h às 20h (seg a sex)",
      hasWifi: true,
      hasRestrooms: true
    });
    
    this.createChargingStation({
      name: "Pão de Açúcar - Morumbi",
      address: "Av. Giovanni Gronchi, 5819 - Morumbi",
      latitude: -23.6230,
      longitude: -46.7368,
      image: "https://images.unsplash.com/photo-1647516738988-ffb0ae4e69ec",
      stationType: "Supermercado",
      power: 22,
      price: 2.10,
      totalSpots: 2,
      availableSpots: 0,
      status: "Unavailable",
      pointsReward: 120,
      openingTime: "7h às 22h (todos os dias)",
      hasCoffee: true,
      hasWifi: true,
      hasRestrooms: true,
      hasShops: true
    });
    
    // Add connectors to stations
    this.createConnector({ stationId: 1, type: "Type2", count: 1 });
    this.createConnector({ stationId: 1, type: "CCS", count: 1 });
    this.createConnector({ stationId: 1, type: "CHAdeMO", count: 1 });
    
    this.createConnector({ stationId: 2, type: "CCS", count: 1 });
    this.createConnector({ stationId: 2, type: "Tesla", count: 1 });
    
    this.createConnector({ stationId: 3, type: "Type2", count: 2 });
    this.createConnector({ stationId: 3, type: "CCS", count: 2 });
    
    this.createConnector({ stationId: 4, type: "Type2", count: 6 });
    
    this.createConnector({ stationId: 5, type: "Type2", count: 1 });
    this.createConnector({ stationId: 5, type: "CCS", count: 1 });
    
    // Create a user
    this.createUser({
      username: "usuario_teste",
      password: "senha123",
      name: "Usuário Teste",
      email: "usuario@teste.com",
      profileImage: "https://randomuser.me/api/portraits/men/54.jpg"
    });
    
    // Add some reviews
    this.createReview({
      userId: 1,
      stationId: 1,
      rating: 5,
      comment: "Ótimo local para carregar, todos os conectores funcionando perfeitamente. O shopping é confortável para esperar enquanto carrega."
    });
    
    this.createReview({
      userId: 1,
      stationId: 2,
      rating: 4,
      comment: "Carregamento rápido e eficiente. Às vezes fica ocupado nos finais de semana, mas durante a semana é tranquilo. Preço justo."
    });
    
    // Update stations with ratings
    this.updateChargingStation(1, { rating: 4.8, reviewCount: 35 });
    this.updateChargingStation(2, { rating: 4.5, reviewCount: 28 });
    this.updateChargingStation(3, { rating: 4.3, reviewCount: 17 });
    this.updateChargingStation(4, { rating: 4.0, reviewCount: 12 });
    this.updateChargingStation(5, { rating: 3.8, reviewCount: 8 });
    
    // Add some charging sessions
    this.createChargingSession({
      userId: 1,
      stationId: 1,
      energy: 30.5,
      cost: 70.15,
      pointsEarned: 150,
      status: "Completed"
    });
    
    this.createChargingSession({
      userId: 1,
      stationId: 3,
      energy: 15.2,
      cost: 30.40,
      pointsEarned: 100,
      status: "Completed"
    });
    
    // Add a favorite station
    this.createFavoriteStation({
      userId: 1,
      stationId: 1
    });
  }
  
  // User operations
  async getUser(id: number): Promise<User | undefined> {
    return this.users.get(id);
  }
  
  async getUserByUsername(username: string): Promise<User | undefined> {
    return Array.from(this.users.values()).find(
      (user) => user.username === username,
    );
  }
  
  async createUser(user: InsertUser): Promise<User> {
    const id = this.userId++;
    const newUser: User = { ...user, id, points: 0 };
    this.users.set(id, newUser);
    return newUser;
  }
  
  async updateUserPoints(userId: number, points: number): Promise<User | undefined> {
    const user = await this.getUser(userId);
    if (!user) return undefined;
    
    const updatedUser: User = {
      ...user,
      points: user.points + points
    };
    
    this.users.set(userId, updatedUser);
    return updatedUser;
  }
  
  // Charging station operations
  async getAllChargingStations(): Promise<ChargingStation[]> {
    return Array.from(this.chargingStations.values());
  }
  
  async getChargingStation(id: number): Promise<ChargingStation | undefined> {
    return this.chargingStations.get(id);
  }
  
  async getNearbyChargingStations(latitude: number, longitude: number, radius: number): Promise<ChargingStation[]> {
    // Simple implementation calculating distance for each station
    const stations = Array.from(this.chargingStations.values());
    return stations.filter(station => {
      const distance = this.calculateDistance(
        latitude, longitude, 
        station.latitude, station.longitude
      );
      return distance <= radius;
    }).sort((a, b) => {
      const distA = this.calculateDistance(latitude, longitude, a.latitude, a.longitude);
      const distB = this.calculateDistance(latitude, longitude, b.latitude, b.longitude);
      return distA - distB;
    });
  }
  
  private calculateDistance(lat1: number, lon1: number, lat2: number, lon2: number): number {
    // Haversine formula to calculate distance between two points on Earth
    const R = 6371; // Radius of the Earth in km
    const dLat = this.deg2rad(lat2 - lat1);
    const dLon = this.deg2rad(lon2 - lon1);
    const a = 
      Math.sin(dLat/2) * Math.sin(dLat/2) +
      Math.cos(this.deg2rad(lat1)) * Math.cos(this.deg2rad(lat2)) * 
      Math.sin(dLon/2) * Math.sin(dLon/2); 
    const c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1-a)); 
    const distance = R * c; // Distance in km
    return distance;
  }
  
  private deg2rad(deg: number): number {
    return deg * (Math.PI/180);
  }
  
  async createChargingStation(station: InsertChargingStation): Promise<ChargingStation> {
    const id = this.stationId++;
    const newStation: ChargingStation = { 
      ...station, 
      id, 
      rating: 0, 
      reviewCount: 0
    };
    this.chargingStations.set(id, newStation);
    return newStation;
  }
  
  async updateChargingStation(id: number, partialStation: Partial<ChargingStation>): Promise<ChargingStation | undefined> {
    const station = await this.getChargingStation(id);
    if (!station) return undefined;
    
    const updatedStation: ChargingStation = {
      ...station,
      ...partialStation
    };
    
    this.chargingStations.set(id, updatedStation);
    return updatedStation;
  }
  
  // Connector operations
  async getConnectorsByStationId(stationId: number): Promise<Connector[]> {
    return Array.from(this.connectors.values())
      .filter(connector => connector.stationId === stationId);
  }
  
  async createConnector(connector: InsertConnector): Promise<Connector> {
    const id = this.connectorId++;
    const newConnector: Connector = { ...connector, id };
    this.connectors.set(id, newConnector);
    return newConnector;
  }
  
  // Review operations
  async getReviewsByStationId(stationId: number): Promise<Review[]> {
    return Array.from(this.reviews.values())
      .filter(review => review.stationId === stationId);
  }
  
  async createReview(review: InsertReview): Promise<Review> {
    const id = this.reviewId++;
    const newReview: Review = { 
      ...review, 
      id, 
      createdAt: new Date() 
    };
    this.reviews.set(id, newReview);
    
    // Update the station's rating and review count
    const station = await this.getChargingStation(review.stationId);
    if (station) {
      const stationReviews = await this.getReviewsByStationId(review.stationId);
      const totalRating = stationReviews.reduce((sum, r) => sum + r.rating, 0);
      const avgRating = totalRating / stationReviews.length;
      
      await this.updateChargingStation(review.stationId, {
        rating: parseFloat(avgRating.toFixed(1)),
        reviewCount: stationReviews.length
      });
    }
    
    return newReview;
  }
  
  // Charging session operations
  async getChargingSessionsByUserId(userId: number): Promise<ChargingSession[]> {
    return Array.from(this.chargingSessions.values())
      .filter(session => session.userId === userId);
  }
  
  async getChargingSessionsByStationId(stationId: number): Promise<ChargingSession[]> {
    return Array.from(this.chargingSessions.values())
      .filter(session => session.stationId === stationId);
  }
  
  async createChargingSession(session: InsertChargingSession): Promise<ChargingSession> {
    const id = this.sessionId++;
    const newSession: ChargingSession = { 
      ...session, 
      id, 
      startTime: new Date(), 
      endTime: undefined
    };
    this.chargingSessions.set(id, newSession);
    
    // Update user points if points earned
    if (session.pointsEarned && session.pointsEarned > 0) {
      await this.updateUserPoints(session.userId, session.pointsEarned);
    }
    
    return newSession;
  }
  
  async updateChargingSession(id: number, partialSession: Partial<ChargingSession>): Promise<ChargingSession | undefined> {
    const session = this.chargingSessions.get(id);
    if (!session) return undefined;
    
    const updatedSession: ChargingSession = {
      ...session,
      ...partialSession,
    };
    
    // If completing the session now, set the end time
    if (session.status !== "Completed" && partialSession.status === "Completed") {
      updatedSession.endTime = new Date();
      
      // Update user points if not already added
      if (session.pointsEarned > 0 && !session.endTime) {
        await this.updateUserPoints(session.userId, session.pointsEarned);
      }
    }
    
    this.chargingSessions.set(id, updatedSession);
    return updatedSession;
  }
  
  // Favorite stations operations
  async getFavoriteStationsByUserId(userId: number): Promise<FavoriteStation[]> {
    return Array.from(this.favoriteStations.values())
      .filter(favorite => favorite.userId === userId);
  }
  
  async createFavoriteStation(favorite: InsertFavoriteStation): Promise<FavoriteStation> {
    // Check if already exists
    const exists = Array.from(this.favoriteStations.values())
      .some(f => f.userId === favorite.userId && f.stationId === favorite.stationId);
    
    if (exists) {
      throw new Error("Station already in favorites");
    }
    
    const id = this.favoriteId++;
    const newFavorite: FavoriteStation = { ...favorite, id };
    this.favoriteStations.set(id, newFavorite);
    return newFavorite;
  }
  
  async deleteFavoriteStation(userId: number, stationId: number): Promise<boolean> {
    const favorite = Array.from(this.favoriteStations.values())
      .find(f => f.userId === userId && f.stationId === stationId);
    
    if (!favorite) return false;
    
    return this.favoriteStations.delete(favorite.id);
  }
}

export const storage = new MemStorage();
