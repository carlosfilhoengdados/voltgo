import type { Express } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import { z } from "zod";
import { 
  insertUserSchema, 
  insertChargingStationSchema, 
  insertReviewSchema, 
  insertChargingSessionSchema, 
  insertFavoriteStationSchema
} from "@shared/schema";

export async function registerRoutes(app: Express): Promise<Server> {
  // User API routes
  app.post("/api/auth/register", async (req, res) => {
    try {
      const userData = insertUserSchema.parse(req.body);
      
      // Check if username already exists
      const existingUser = await storage.getUserByUsername(userData.username);
      if (existingUser) {
        return res.status(400).json({ message: "Username already exists" });
      }
      
      const user = await storage.createUser(userData);
      // Don't return the password
      const { password, ...userWithoutPassword } = user;
      
      return res.status(201).json(userWithoutPassword);
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ message: "Invalid user data", errors: error.errors });
      }
      return res.status(500).json({ message: "Failed to create user" });
    }
  });
  
  app.post("/api/auth/login", async (req, res) => {
    try {
      const { username, password } = req.body;
      
      if (!username || !password) {
        return res.status(400).json({ message: "Username and password are required" });
      }
      
      const user = await storage.getUserByUsername(username);
      if (!user || user.password !== password) {
        return res.status(401).json({ message: "Invalid username or password" });
      }
      
      // Don't return the password
      const { password: _, ...userWithoutPassword } = user;
      
      return res.status(200).json(userWithoutPassword);
    } catch (error) {
      return res.status(500).json({ message: "Failed to login" });
    }
  });
  
  app.get("/api/users/:id", async (req, res) => {
    try {
      const userId = parseInt(req.params.id);
      if (isNaN(userId)) {
        return res.status(400).json({ message: "Invalid user ID" });
      }
      
      const user = await storage.getUser(userId);
      if (!user) {
        return res.status(404).json({ message: "User not found" });
      }
      
      // Don't return the password
      const { password, ...userWithoutPassword } = user;
      
      return res.status(200).json(userWithoutPassword);
    } catch (error) {
      return res.status(500).json({ message: "Failed to get user" });
    }
  });
  
  // Charging stations API routes
  app.get("/api/stations", async (req, res) => {
    try {
      const stations = await storage.getAllChargingStations();
      return res.status(200).json(stations);
    } catch (error) {
      return res.status(500).json({ message: "Failed to get charging stations" });
    }
  });
  
  app.get("/api/stations/nearby", async (req, res) => {
    try {
      const { latitude, longitude, radius = 5 } = req.query;
      
      if (!latitude || !longitude) {
        return res.status(400).json({ message: "Latitude and longitude are required" });
      }
      
      const lat = parseFloat(latitude as string);
      const lng = parseFloat(longitude as string);
      const rad = parseFloat(radius as string);
      
      if (isNaN(lat) || isNaN(lng)) {
        return res.status(400).json({ message: "Invalid latitude or longitude" });
      }
      
      const stations = await storage.getNearbyChargingStations(lat, lng, rad);
      return res.status(200).json(stations);
    } catch (error) {
      return res.status(500).json({ message: "Failed to get nearby charging stations" });
    }
  });
  
  app.get("/api/stations/:id", async (req, res) => {
    try {
      const stationId = parseInt(req.params.id);
      if (isNaN(stationId)) {
        return res.status(400).json({ message: "Invalid station ID" });
      }
      
      const station = await storage.getChargingStation(stationId);
      if (!station) {
        return res.status(404).json({ message: "Charging station not found" });
      }
      
      return res.status(200).json(station);
    } catch (error) {
      return res.status(500).json({ message: "Failed to get charging station" });
    }
  });
  
  app.post("/api/stations", async (req, res) => {
    try {
      const stationData = insertChargingStationSchema.parse(req.body);
      const station = await storage.createChargingStation(stationData);
      return res.status(201).json(station);
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ message: "Invalid station data", errors: error.errors });
      }
      return res.status(500).json({ message: "Failed to create charging station" });
    }
  });
  
  app.patch("/api/stations/:id", async (req, res) => {
    try {
      const stationId = parseInt(req.params.id);
      if (isNaN(stationId)) {
        return res.status(400).json({ message: "Invalid station ID" });
      }
      
      const station = await storage.getChargingStation(stationId);
      if (!station) {
        return res.status(404).json({ message: "Charging station not found" });
      }
      
      const updatedStation = await storage.updateChargingStation(stationId, req.body);
      return res.status(200).json(updatedStation);
    } catch (error) {
      return res.status(500).json({ message: "Failed to update charging station" });
    }
  });
  
  // Connectors API routes
  app.get("/api/stations/:stationId/connectors", async (req, res) => {
    try {
      const stationId = parseInt(req.params.stationId);
      if (isNaN(stationId)) {
        return res.status(400).json({ message: "Invalid station ID" });
      }
      
      const connectors = await storage.getConnectorsByStationId(stationId);
      return res.status(200).json(connectors);
    } catch (error) {
      return res.status(500).json({ message: "Failed to get connectors" });
    }
  });
  
  // Reviews API routes
  app.get("/api/stations/:stationId/reviews", async (req, res) => {
    try {
      const stationId = parseInt(req.params.stationId);
      if (isNaN(stationId)) {
        return res.status(400).json({ message: "Invalid station ID" });
      }
      
      const reviews = await storage.getReviewsByStationId(stationId);
      return res.status(200).json(reviews);
    } catch (error) {
      return res.status(500).json({ message: "Failed to get reviews" });
    }
  });
  
  app.post("/api/stations/:stationId/reviews", async (req, res) => {
    try {
      const stationId = parseInt(req.params.stationId);
      if (isNaN(stationId)) {
        return res.status(400).json({ message: "Invalid station ID" });
      }
      
      const reviewData = insertReviewSchema.parse({
        ...req.body,
        stationId
      });
      
      const review = await storage.createReview(reviewData);
      return res.status(201).json(review);
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ message: "Invalid review data", errors: error.errors });
      }
      return res.status(500).json({ message: "Failed to create review" });
    }
  });
  
  // Charging sessions API routes
  app.get("/api/users/:userId/sessions", async (req, res) => {
    try {
      const userId = parseInt(req.params.userId);
      if (isNaN(userId)) {
        return res.status(400).json({ message: "Invalid user ID" });
      }
      
      const sessions = await storage.getChargingSessionsByUserId(userId);
      return res.status(200).json(sessions);
    } catch (error) {
      return res.status(500).json({ message: "Failed to get charging sessions" });
    }
  });
  
  app.post("/api/sessions", async (req, res) => {
    try {
      const sessionData = insertChargingSessionSchema.parse(req.body);
      const session = await storage.createChargingSession(sessionData);
      return res.status(201).json(session);
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ message: "Invalid session data", errors: error.errors });
      }
      return res.status(500).json({ message: "Failed to create charging session" });
    }
  });
  
  app.patch("/api/sessions/:id", async (req, res) => {
    try {
      const sessionId = parseInt(req.params.id);
      if (isNaN(sessionId)) {
        return res.status(400).json({ message: "Invalid session ID" });
      }
      
      const updatedSession = await storage.updateChargingSession(sessionId, req.body);
      
      if (!updatedSession) {
        return res.status(404).json({ message: "Charging session not found" });
      }
      
      return res.status(200).json(updatedSession);
    } catch (error) {
      return res.status(500).json({ message: "Failed to update charging session" });
    }
  });
  
  // Favorite stations API routes
  app.get("/api/users/:userId/favorites", async (req, res) => {
    try {
      const userId = parseInt(req.params.userId);
      if (isNaN(userId)) {
        return res.status(400).json({ message: "Invalid user ID" });
      }
      
      const favorites = await storage.getFavoriteStationsByUserId(userId);
      
      // Get the actual stations
      const stationPromises = favorites.map(async (favorite) => {
        return await storage.getChargingStation(favorite.stationId);
      });
      
      const stations = await Promise.all(stationPromises);
      const filteredStations = stations.filter(station => station !== undefined);
      
      return res.status(200).json(filteredStations);
    } catch (error) {
      return res.status(500).json({ message: "Failed to get favorite stations" });
    }
  });
  
  app.post("/api/users/:userId/favorites", async (req, res) => {
    try {
      const userId = parseInt(req.params.userId);
      if (isNaN(userId)) {
        return res.status(400).json({ message: "Invalid user ID" });
      }
      
      const { stationId } = req.body;
      if (!stationId) {
        return res.status(400).json({ message: "Station ID is required" });
      }
      
      const favoriteData = insertFavoriteStationSchema.parse({
        userId,
        stationId
      });
      
      const favorite = await storage.createFavoriteStation(favoriteData);
      return res.status(201).json(favorite);
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ message: "Invalid favorite data", errors: error.errors });
      } else if (error instanceof Error && error.message === "Station already in favorites") {
        return res.status(400).json({ message: error.message });
      }
      return res.status(500).json({ message: "Failed to create favorite station" });
    }
  });
  
  app.delete("/api/users/:userId/favorites/:stationId", async (req, res) => {
    try {
      const userId = parseInt(req.params.userId);
      const stationId = parseInt(req.params.stationId);
      if (isNaN(userId) || isNaN(stationId)) {
        return res.status(400).json({ message: "Invalid user ID or station ID" });
      }
      
      const success = await storage.deleteFavoriteStation(userId, stationId);
      
      if (!success) {
        return res.status(404).json({ message: "Favorite station not found" });
      }
      
      return res.status(204).end();
    } catch (error) {
      return res.status(500).json({ message: "Failed to delete favorite station" });
    }
  });

  const httpServer = createServer(app);
  return httpServer;
}
