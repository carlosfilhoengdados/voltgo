import { useLocation } from "wouter";
import { useAuth } from "@/contexts/AuthContext";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { Bell, ChevronLeft, Sliders } from "lucide-react";
import { Badge } from "@/components/ui/badge";

interface HeaderProps {
  title?: string;
  backTo?: string;
  onFilterClick?: () => void;
}

export default function Header({ title, backTo, onFilterClick }: HeaderProps) {
  const [_, setLocation] = useLocation();
  const { user } = useAuth();
  
  const handleBackClick = () => {
    if (backTo) {
      setLocation(backTo);
    }
  };
  
  const handleProfileClick = () => {
    setLocation("/profile");
  };

  return (
    <header className="bg-white shadow-sm z-20">
      <div className="container mx-auto px-4 py-3 flex justify-between items-center">
        <div className="flex items-center">
          {backTo ? (
            <button 
              onClick={handleBackClick} 
              className="mr-3 hover:bg-gray-100 rounded-full p-1"
            >
              <ChevronLeft className="h-5 w-5" />
            </button>
          ) : (
            <div className="text-primary mr-2">
              <i className="fas fa-bolt text-2xl"></i>
            </div>
          )}
          
          <h1 className="font-heading font-bold text-xl text-dark">
            {title || (
              <>
                Volt<span className="text-primary">Go</span>
              </>
            )}
          </h1>
        </div>
        
        <div className="flex items-center gap-3">
          {onFilterClick && (
            <button 
              onClick={onFilterClick} 
              className="bg-white border border-gray-200 rounded-full p-2 shadow-sm hover:bg-gray-50"
            >
              <Sliders className="h-4 w-4 text-dark" />
            </button>
          )}
          
          <div className="relative">
            <button 
              onClick={() => {}} // Handle notifications
              className="bg-white border border-gray-200 rounded-full p-2 shadow-sm hover:bg-gray-50"
            >
              <Bell className="h-4 w-4 text-dark" />
              <Badge className="absolute -top-1 -right-1 bg-accent text-white text-xs rounded-full h-4 w-4 flex items-center justify-center p-0">
                2
              </Badge>
            </button>
          </div>
          
          <button 
            onClick={handleProfileClick} 
            className="bg-white border border-gray-200 rounded-full p-1 shadow-sm hover:bg-gray-50"
          >
            {user ? (
              <Avatar className="h-6 w-6">
                <AvatarImage src={user.profileImage} alt={user.name} />
                <AvatarFallback className="text-xs">{user.name.charAt(0)}</AvatarFallback>
              </Avatar>
            ) : (
              <div className="h-6 w-6 rounded-full bg-gray-200 flex items-center justify-center">
                <i className="fas fa-user text-xs text-gray-500"></i>
              </div>
            )}
          </button>
        </div>
      </div>
    </header>
  );
}
