import { ChargingStation } from "@shared/schema";
import { Badge } from "@/components/ui/badge";
import { MapPin, Zap, TicketIcon } from "lucide-react";

interface ChargingStationCardProps {
  station: ChargingStation;
  onClick?: () => void;
}

export default function ChargingStationCard({ station, onClick }: ChargingStationCardProps) {
  // Helper function to get status badge
  const getStatusBadge = (status: string) => {
    switch (status) {
      case "Available":
        return (
          <div className="absolute top-3 right-3 bg-primary/90 text-white text-xs font-medium px-2 py-1 rounded-md backdrop-blur-sm">
            <Zap className="inline-block h-3 w-3 mr-1" /> Disponível
          </div>
        );
      case "Occupied":
        return (
          <div className="absolute top-3 right-3 bg-warning/90 text-white text-xs font-medium px-2 py-1 rounded-md backdrop-blur-sm">
            <i className="fas fa-clock mr-1"></i> Ocupado
          </div>
        );
      case "Unavailable":
        return (
          <div className="absolute top-3 right-3 bg-danger/90 text-white text-xs font-medium px-2 py-1 rounded-md backdrop-blur-sm">
            <i className="fas fa-exclamation-triangle mr-1"></i> Indisponível
          </div>
        );
      default:
        return null;
    }
  };

  // Helper function to get station type icon
  const getStationTypeIcon = (type: string) => {
    switch (type.toLowerCase()) {
      case "shopping":
        return <i className="fas fa-shopping-bag mr-1"></i>;
      case "supercarregador":
        return <i className="fas fa-charging-station mr-1"></i>;
      case "café":
        return <i className="fas fa-coffee mr-1"></i>;
      case "corporativo":
        return <i className="fas fa-building mr-1"></i>;
      case "supermercado":
        return <i className="fas fa-store mr-1"></i>;
      default:
        return <i className="fas fa-plug mr-1"></i>;
    }
  };

  // Helper function to get action button based on status
  const getActionButton = (status: string) => {
    switch (status) {
      case "Available":
        return (
          <button className="bg-primary/10 text-primary text-sm px-3 py-1 rounded-full font-medium hover:bg-primary/20">
            Navegar
          </button>
        );
      case "Occupied":
        return (
          <button className="bg-warning/10 text-warning text-sm px-3 py-1 rounded-full font-medium">
            Ocupado
          </button>
        );
      case "Unavailable":
        return (
          <button className="bg-danger/10 text-danger text-sm px-3 py-1 rounded-full font-medium">
            Em manutenção
          </button>
        );
      default:
        return (
          <button className="bg-gray-100 text-gray-500 text-sm px-3 py-1 rounded-full font-medium">
            Indisponível
          </button>
        );
    }
  };

  return (
    <div 
      className="eletroposto-card bg-white rounded-xl border border-gray-100 shadow-sm w-full flex-shrink-0 overflow-hidden cursor-pointer hover:shadow-md transition-all"
      onClick={onClick}
    >
      <div className="relative">
        <img 
          src={`${station.image}?auto=format&fit=crop&w=320&h=160&q=80`} 
          alt={station.name} 
          className="h-36 w-full object-cover"
          onError={(e) => {
            // Fallback image if loading fails
            (e.target as HTMLImageElement).src = "https://images.unsplash.com/photo-1593941707882-a156679de2f5?auto=format&fit=crop&w=320&h=160&q=80";
          }}
        />
        
        {getStatusBadge(station.status)}
        
        <div className="absolute top-3 left-3 bg-white/90 text-dark text-xs font-medium px-2 py-1 rounded-md backdrop-blur-sm">
          {getStationTypeIcon(station.stationType)} {station.stationType}
        </div>
      </div>
      
      <div className="p-3">
        <div className="flex justify-between">
          <h3 className="font-heading font-semibold truncate">{station.name}</h3>
          <div className="flex items-center text-accent">
            <i className="fas fa-star text-xs mr-1"></i>
            <span className="text-sm font-medium">{station.rating}</span>
          </div>
        </div>
        
        <p className="text-gray-500 text-sm mt-1 flex items-center">
          <MapPin className="h-3 w-3 mr-1 flex-shrink-0" /> 
          <span className="truncate">{station.address}</span>
        </p>
        
        <div className="mt-3 flex justify-between items-center">
          <div>
            <div className="flex items-center text-sm">
              <span className="text-gray-600 font-medium">{station.power} kW</span>
              <span className="mx-2 text-gray-300">|</span>
              <span className="text-gray-600">
                {station.availableSpots}/{station.totalSpots} livres
              </span>
            </div>
            <div className="text-sm text-primary font-medium mt-1">
              <TicketIcon className="h-3 w-3 mr-1 inline-block" />
              +{station.pointsReward} pontos
            </div>
          </div>
          
          {getActionButton(station.status)}
        </div>
      </div>
    </div>
  );
}
