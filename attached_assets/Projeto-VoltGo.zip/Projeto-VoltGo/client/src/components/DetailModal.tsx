import { useState } from "react";
import { ChargingStation, Review, Connector } from "@shared/schema";
import { useQuery } from "@tanstack/react-query";
import { useAuth } from "@/contexts/AuthContext";
import { Dialog, DialogContent } from "@/components/ui/dialog";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import RatingStars from "./RatingStars";
import { useToast } from "@/hooks/use-toast";
import { apiRequest } from "@/lib/queryClient";
import { 
  X, MapPin, Zap, QrCode, Bookmark, 
  Wifi, Coffee, Compass, ShoppingBag,
  ParkingCircle, Utensils 
} from "lucide-react";

interface DetailModalProps {
  isOpen: boolean;
  station: ChargingStation;
  onClose: () => void;
}

export default function DetailModal({ isOpen, station, onClose }: DetailModalProps) {
  const { user } = useAuth();
  const { toast } = useToast();
  const [isNavigating, setIsNavigating] = useState(false);
  const [isSaving, setIsSaving] = useState(false);
  const [isCheckinIn, setIsCheckingIn] = useState(false);
  
  // Fetch station reviews
  const { data: reviews = [], isLoading: reviewsLoading } = useQuery<Review[]>({
    queryKey: [`/api/stations/${station.id}/reviews`],
    enabled: isOpen,
  });
  
  // Fetch station connectors
  const { data: connectors = [], isLoading: connectorsLoading } = useQuery<Connector[]>({
    queryKey: [`/api/stations/${station.id}/connectors`],
    enabled: isOpen,
  });
  
  // Check if station is in user's favorites
  const { data: favorites = [], isLoading: favoritesLoading } = useQuery<ChargingStation[]>({
    queryKey: [`/api/users/${user?.id}/favorites`],
    enabled: !!user && isOpen,
  });
  
  const isStationFavorite = favorites.some((fav: ChargingStation) => fav.id === station.id);
  
  const handleNavigate = () => {
    setIsNavigating(true);
    
    // Open in Google Maps
    const mapUrl = `https://www.google.com/maps/dir/?api=1&destination=${station.latitude},${station.longitude}`;
    window.open(mapUrl, '_blank');
    
    setIsNavigating(false);
  };
  
  const handleSaveToFavorites = async () => {
    if (!user) {
      toast({
        title: "Login necessário",
        description: "Faça login para salvar eletropostos favoritos",
        variant: "destructive",
      });
      return;
    }
    
    setIsSaving(true);
    
    try {
      if (isStationFavorite) {
        // Remove from favorites
        await apiRequest('DELETE', `/api/users/${user.id}/favorites/${station.id}`);
        toast({
          title: "Removido dos favoritos",
          description: "Eletroposto removido dos seus favoritos com sucesso",
        });
      } else {
        // Add to favorites
        await apiRequest('POST', `/api/users/${user.id}/favorites`, { stationId: station.id });
        toast({
          title: "Adicionado aos favoritos",
          description: "Eletroposto adicionado aos seus favoritos com sucesso",
        });
      }
    } catch (error) {
      toast({
        title: "Erro",
        description: "Não foi possível atualizar seus favoritos",
        variant: "destructive",
      });
    } finally {
      setIsSaving(false);
    }
  };
  
  const handleCheckIn = async () => {
    if (!user) {
      toast({
        title: "Login necessário",
        description: "Faça login para fazer check-in e ganhar pontos",
        variant: "destructive",
      });
      return;
    }
    
    setIsCheckingIn(true);
    
    try {
      // Create a new charging session
      await apiRequest('POST', '/api/sessions', {
        userId: user.id,
        stationId: station.id,
        pointsEarned: station.pointsReward,
        status: "Active"
      });
      
      toast({
        title: "Check-in realizado!",
        description: `Você ganhou ${station.pointsReward} pontos!`,
      });
      
      onClose();
    } catch (error) {
      toast({
        title: "Erro no check-in",
        description: "Não foi possível fazer check-in neste eletroposto",
        variant: "destructive",
      });
    } finally {
      setIsCheckingIn(false);
    }
  };
  
  // Helper function to get status class
  const getStatusStyles = (status: string) => {
    switch (status) {
      case "Available":
        return "bg-green-50 border-green-100 text-green-800";
      case "Occupied":
        return "bg-amber-50 border-amber-100 text-amber-800";
      case "Unavailable":
        return "bg-red-50 border-red-100 text-red-800";
      default:
        return "bg-gray-50 border-gray-100 text-gray-800";
    }
  };
  
  // Helper function to get status icon
  const getStatusIcon = (status: string) => {
    switch (status) {
      case "Available":
        return <Zap className="text-primary" />;
      case "Occupied":
        return <i className="fas fa-clock text-amber-500"></i>;
      case "Unavailable":
        return <i className="fas fa-exclamation-triangle text-red-500"></i>;
      default:
        return <i className="fas fa-question-circle text-gray-500"></i>;
    }
  };
  
  // Format date from reviews
  const formatReviewDate = (dateString: string) => {
    const date = new Date(dateString);
    const now = new Date();
    const diffTime = Math.abs(now.getTime() - date.getTime());
    const diffDays = Math.ceil(diffTime / (1000 * 60 * 60 * 24));
    
    if (diffDays === 1) return "há 1 dia";
    if (diffDays < 7) return `há ${diffDays} dias`;
    if (diffDays < 30) return `há ${Math.floor(diffDays / 7)} semanas`;
    if (diffDays < 365) return `há ${Math.floor(diffDays / 30)} meses`;
    return `há ${Math.floor(diffDays / 365)} anos`;
  };
  
  // Helper function to get station type icon
  const getStationTypeIcon = (type: string) => {
    switch (type.toLowerCase()) {
      case "shopping":
        return <ShoppingBag className="h-3 w-3 mr-1" />;
      case "supercarregador":
        return <Zap className="h-3 w-3 mr-1" />;
      case "café":
        return <Coffee className="h-3 w-3 mr-1" />;
      case "corporativo":
        return <i className="fas fa-building mr-1 text-xs"></i>;
      case "supermercado":
        return <i className="fas fa-store mr-1 text-xs"></i>;
      default:
        return <Compass className="h-3 w-3 mr-1" />;
    }
  };

  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="p-0 max-w-lg max-h-[90vh] overflow-hidden flex flex-col">
        <button 
          onClick={onClose}
          className="absolute top-4 right-4 bg-white/80 rounded-full p-2 text-dark backdrop-blur-sm z-10"
        >
          <X className="h-4 w-4" />
        </button>
        
        <div className="relative">
          <img
            src={`${station.image}?auto=format&fit=crop&w=640&h=320&q=80`}
            alt={station.name}
            className="w-full h-48 object-cover"
          />
          <div className="absolute bottom-0 left-0 right-0 bg-gradient-to-t from-black/60 to-transparent p-4">
            <div className="flex justify-between items-end">
              <div>
                <Badge 
                  variant="outline" 
                  className="bg-white/90 text-dark backdrop-blur-sm border-0"
                >
                  {getStationTypeIcon(station.stationType)} {station.stationType}
                </Badge>
                <h2 className="text-white font-heading font-bold text-xl mt-2 drop-shadow-sm">
                  {station.name}
                </h2>
              </div>
              <Badge 
                variant="outline" 
                className="bg-white/90 text-dark backdrop-blur-sm border-0 flex items-center"
              >
                <i className="fas fa-star text-accent mr-1"></i>
                <span>{station.rating}</span>
                <span className="text-xs text-gray-500 ml-1">({station.reviewCount})</span>
              </Badge>
            </div>
          </div>
        </div>
        
        <div className="overflow-y-auto p-4 flex-1">
          <div className="flex items-center justify-between mb-4">
            <div className="flex items-center">
              <MapPin className="text-primary mr-2 h-4 w-4" />
              <span className="text-gray-700">{station.address}</span>
            </div>
            <Button 
              variant="ghost" 
              size="sm" 
              className="text-primary flex items-center"
              onClick={handleNavigate}
              disabled={isNavigating}
            >
              <Compass className="mr-1 h-4 w-4" />
              {isNavigating ? "Abrindo..." : "Navegar"}
            </Button>
          </div>
          
          <div className={`border rounded-lg p-3 flex items-center justify-between mb-4 ${getStatusStyles(station.status)}`}>
            <div className="flex items-center">
              <div className="bg-primary h-10 w-10 rounded-full flex items-center justify-center text-white mr-3">
                {getStatusIcon(station.status)}
              </div>
              <div>
                <p className="font-medium">
                  {station.status === "Available" 
                    ? "Disponível agora" 
                    : station.status === "Occupied" 
                      ? "Ocupado" 
                      : "Indisponível"}
                </p>
                <p className="text-sm">
                  {station.availableSpots} de {station.totalSpots} pontos livres
                </p>
              </div>
            </div>
            <div className="text-primary font-medium text-lg">
              <Zap className="mr-1 h-5 w-5 inline" /> +{station.pointsReward} pontos
            </div>
          </div>
          
          <div className="grid grid-cols-2 gap-3 mb-4">
            <div className="bg-gray-50 border border-gray-100 rounded-lg p-3">
              <p className="text-sm text-gray-500 mb-1">Potência</p>
              <p className="font-medium">
                {station.power} kW {station.power >= 50 ? "(DC rápido)" : "(AC)"}
              </p>
            </div>
            <div className="bg-gray-50 border border-gray-100 rounded-lg p-3">
              <p className="text-sm text-gray-500 mb-1">Conectores</p>
              <p className="font-medium">
                {connectorsLoading 
                  ? "Carregando..." 
                  : connectors?.map((c: Connector) => c.type).join(", ") || "Não especificado"}
              </p>
            </div>
            <div className="bg-gray-50 border border-gray-100 rounded-lg p-3">
              <p className="text-sm text-gray-500 mb-1">Horário</p>
              <p className="font-medium">{station.openingTime}</p>
            </div>
            <div className="bg-gray-50 border border-gray-100 rounded-lg p-3">
              <p className="text-sm text-gray-500 mb-1">Preço médio</p>
              <p className="font-medium">
                {station.price ? `R$ ${station.price.toFixed(2)}/kWh` : "Não informado"}
              </p>
            </div>
          </div>
          
          <div className="mb-4">
            <h3 className="font-heading font-semibold text-lg mb-2">Serviços adicionais</h3>
            <div className="flex flex-wrap gap-2">
              {station.hasWifi && (
                <Badge variant="secondary" className="flex items-center">
                  <Wifi className="mr-1 h-3 w-3" /> WiFi grátis
                </Badge>
              )}
              {station.hasCoffee && (
                <Badge variant="secondary" className="flex items-center">
                  <Coffee className="mr-1 h-3 w-3" /> Café
                </Badge>
              )}
              {station.hasRestrooms && (
                <Badge variant="secondary" className="flex items-center">
                  <i className="fas fa-restroom mr-1 text-xs"></i> Banheiros
                </Badge>
              )}
              {station.hasShops && (
                <Badge variant="secondary" className="flex items-center">
                  <ShoppingBag className="mr-1 h-3 w-3" /> Lojas
                </Badge>
              )}
              {station.hasRestaurants && (
                <Badge variant="secondary" className="flex items-center">
                  <Utensils className="mr-1 h-3 w-3" /> Restaurantes
                </Badge>
              )}
              {station.hasFreeParking && (
                <Badge variant="secondary" className="flex items-center">
                  <ParkingCircle className="mr-1 h-3 w-3" /> Estacionamento grátis
                </Badge>
              )}
              {!station.hasWifi && !station.hasCoffee && !station.hasRestrooms && 
               !station.hasShops && !station.hasRestaurants && !station.hasFreeParking && (
                <p className="text-sm text-gray-500">Nenhum serviço adicional informado</p>
              )}
            </div>
          </div>
          
          <div className="mb-4">
            <div className="flex justify-between items-center mb-2">
              <h3 className="font-heading font-semibold text-lg">Avaliações</h3>
              <Button variant="link" className="text-primary p-0 h-auto" size="sm">
                Ver todas ({station.reviewCount})
              </Button>
            </div>
            
            {reviewsLoading ? (
              <div className="py-4 text-center">
                <p className="text-sm text-gray-500">Carregando avaliações...</p>
              </div>
            ) : !reviews || reviews.length === 0 ? (
              <div className="py-4 text-center">
                <p className="text-sm text-gray-500">Nenhuma avaliação disponível</p>
              </div>
            ) : (
              reviews.slice(0, 2).map((review: Review) => (
                <div key={review.id} className="border-t border-gray-100 py-3">
                  <div className="flex justify-between items-start">
                    <div className="flex items-start">
                      <div className="h-10 w-10 rounded-full bg-gray-200 mr-3 overflow-hidden flex items-center justify-center">
                        <i className="fas fa-user text-gray-400"></i>
                      </div>
                      <div>
                        <p className="font-medium">Usuário {review.userId}</p>
                        <div className="flex items-center mt-1">
                          <RatingStars rating={review.rating} />
                          <span className="text-xs text-gray-500 ml-2">
                            {formatReviewDate(review.createdAt.toString())}
                          </span>
                        </div>
                      </div>
                    </div>
                  </div>
                  <p className="text-gray-600 text-sm mt-2">
                    {review.comment || "Sem comentário."}
                  </p>
                </div>
              ))
            )}
          </div>
        </div>
        
        <div className="p-4 border-t border-gray-100 flex gap-2">
          <Button 
            variant="outline" 
            className="flex-1"
            onClick={handleSaveToFavorites}
            disabled={isSaving || favoritesLoading}
          >
            <Bookmark className={`mr-1 h-4 w-4 ${isStationFavorite ? 'fill-current' : ''}`} />
            {isSaving ? "Salvando..." : isStationFavorite ? "Salvo" : "Salvar"}
          </Button>
          <Button 
            className="flex-1 bg-primary hover:bg-green-500"
            onClick={handleCheckIn}
            disabled={isCheckinIn || station.status !== "Available"}
          >
            <QrCode className="mr-1 h-4 w-4" />
            {isCheckinIn ? "Processando..." : "Check-in"}
          </Button>
        </div>
      </DialogContent>
    </Dialog>
  );
}
