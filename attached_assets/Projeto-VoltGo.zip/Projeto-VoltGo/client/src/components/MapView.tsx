import { useEffect, useRef, useState } from "react";
import { ChargingStation } from "@shared/schema";
import { createMap, createMarker, initializeMap, updateMapCenter } from "@/lib/map";
import { Loader2 } from "lucide-react";

interface MapViewProps {
  userLocation: { latitude: number; longitude: number } | null;
  stations: ChargingStation[];
  onMarkerClick: (station: ChargingStation) => void;
}

export default function MapView({ userLocation, stations, onMarkerClick }: MapViewProps) {
  const mapContainerRef = useRef<HTMLDivElement>(null);
  const [map, setMap] = useState<mapboxgl.Map | null>(null);
  const [markers, setMarkers] = useState<{ [id: number]: mapboxgl.Marker }>({});
  const [isMapLoading, setIsMapLoading] = useState(true);

  // Initialize map when component mounts
  useEffect(() => {
    if (!mapContainerRef.current) return;

    const initialCenter = userLocation 
      ? [userLocation.longitude, userLocation.latitude] 
      : [-46.6333, -23.5505]; // Default to São Paulo
    
    const initMapAsync = async () => {
      try {
        await initializeMap();
        const newMap = createMap(mapContainerRef.current, initialCenter);
        setMap(newMap);
        
        // Add user location marker if available
        if (userLocation) {
          createMarker(
            newMap, 
            [userLocation.longitude, userLocation.latitude], 
            'user-location', 
            'blue'
          );
        }
        
        newMap.on('load', () => {
          setIsMapLoading(false);
        });
      } catch (error) {
        console.error('Error initializing map:', error);
        setIsMapLoading(false);
      }
    };

    initMapAsync();

    return () => {
      if (map) {
        map.remove();
      }
    };
  }, []);

  // Update map center when user location changes
  useEffect(() => {
    if (!map || !userLocation) return;
    
    updateMapCenter(
      map, 
      [userLocation.longitude, userLocation.latitude]
    );
    
    // Update or create user location marker
    const userMarkerElement = document.querySelector('.user-location-marker');
    
    if (!userMarkerElement) {
      createMarker(
        map, 
        [userLocation.longitude, userLocation.latitude], 
        'user-location', 
        'blue'
      );
    } else {
      // Update existing marker position
      const marker = markers['user-location'];
      if (marker) {
        marker.setLngLat([userLocation.longitude, userLocation.latitude]);
      }
    }
  }, [userLocation, map]);

  // Add/update station markers when stations change
  useEffect(() => {
    if (!map) return;
    
    // Remove old markers
    Object.values(markers).forEach(marker => {
      if (marker && marker.getElement().id !== 'user-location-marker') {
        marker.remove();
      }
    });
    
    const newMarkers: { [id: number]: mapboxgl.Marker } = {};
    
    // Add markers for each station
    stations.forEach(station => {
      // Create marker with the appropriate color based on status
      let color = 'green';
      if (station.status === 'Occupied') color = 'orange';
      if (station.status === 'Unavailable') color = 'red';
      
      const marker = createMarker(
        map,
        [station.longitude, station.latitude],
        `station-${station.id}`,
        color,
        true // include pulse effect for stations
      );
      
      // Add click handler
      marker.getElement().addEventListener('click', () => {
        onMarkerClick(station);
      });
      
      newMarkers[station.id] = marker;
    });
    
    // Keep user location marker if it exists
    if (markers['user-location']) {
      newMarkers['user-location'] = markers['user-location'];
    }
    
    setMarkers(newMarkers);
  }, [stations, map, onMarkerClick]);

  return (
    <div className="relative w-full h-full">
      <div 
        id="map" 
        ref={mapContainerRef} 
        className="w-full map-container bg-gray-100 h-full"
      ></div>
      
      {isMapLoading && (
        <div className="absolute inset-0 flex items-center justify-center bg-white/80">
          <Loader2 className="h-10 w-10 text-primary animate-spin" />
          <span className="ml-2 text-primary font-medium">Carregando mapa...</span>
        </div>
      )}
    </div>
  );
}
