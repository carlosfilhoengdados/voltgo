import { useState, useRef, useEffect } from "react";
import { ChargingStation } from "@shared/schema";
import ChargingStationCard from "./ChargingStationCard";
import { Loader2 } from "lucide-react";

interface ElectropostosPanelProps {
  stations: ChargingStation[];
  loading: boolean;
  onStationClick: (station: ChargingStation) => void;
}

export default function ElectropostosPanel({ 
  stations, 
  loading,
  onStationClick 
}: ElectropostosPanelProps) {
  const [panelHeight, setPanelHeight] = useState(180); // Default collapsed height
  const panelRef = useRef<HTMLDivElement>(null);
  const dragHandleRef = useRef<HTMLDivElement>(null);
  const [isDragging, setIsDragging] = useState(false);
  const [startY, setStartY] = useState(0);
  const [startHeight, setStartHeight] = useState(0);

  const initDrag = (e: React.MouseEvent | React.TouchEvent) => {
    setIsDragging(true);
    
    // Get the initial position
    if ('touches' in e) {
      setStartY(e.touches[0].clientY);
    } else {
      setStartY(e.clientY);
    }
    
    // Get the current panel height
    if (panelRef.current) {
      setStartHeight(panelRef.current.offsetHeight);
    }
    
    // Add event listeners
    document.addEventListener('mousemove', doDrag);
    document.addEventListener('touchmove', doDrag);
    document.addEventListener('mouseup', stopDrag);
    document.addEventListener('touchend', stopDrag);
  };

  const doDrag = (e: MouseEvent | TouchEvent) => {
    if (!isDragging) return;
    
    let y;
    if ('touches' in e) {
      y = e.touches[0].clientY;
    } else {
      y = e.clientY;
    }
    
    const deltaY = y - startY;
    
    // Calculate new height (inverse of the drag direction)
    const newHeight = startHeight - deltaY;
    
    // Constrain the panel height
    const maxHeight = window.innerHeight * 0.8;
    const minHeight = 120;
    
    if (newHeight >= minHeight && newHeight <= maxHeight) {
      setPanelHeight(newHeight);
    }
  };

  const stopDrag = () => {
    setIsDragging(false);
    
    // Remove event listeners
    document.removeEventListener('mousemove', doDrag);
    document.removeEventListener('touchmove', doDrag);
    document.removeEventListener('mouseup', stopDrag);
    document.removeEventListener('touchend', stopDrag);
    
    // Snap to predefined heights
    if (panelRef.current) {
      const windowHeight = window.innerHeight;
      const currentHeight = panelRef.current.offsetHeight;
      
      if (currentHeight < windowHeight * 0.3) {
        // Snap to collapsed
        setPanelHeight(180);
      } else if (currentHeight < windowHeight * 0.6) {
        // Snap to half
        setPanelHeight(windowHeight * 0.4);
      } else {
        // Snap to expanded
        setPanelHeight(windowHeight * 0.8);
      }
    }
  };

  return (
    <div 
      ref={panelRef}
      className="absolute bottom-0 left-0 right-0 z-30 bg-white rounded-t-xl shadow-xl pb-16 md:pb-4"
      style={{ height: `${panelHeight}px` }}
    >
      <div 
        ref={dragHandleRef}
        className="p-2 flex justify-center cursor-grab"
        onMouseDown={initDrag}
        onTouchStart={initDrag}
      >
        <div className="w-10 h-1 bg-gray-300 rounded-full"></div>
      </div>
      
      <div className="px-4 pb-2 flex justify-between items-center">
        <h2 className="font-heading font-semibold text-lg">Eletropostos próximos</h2>
        <div className="text-sm text-gray-500">
          <span className="font-medium">{stations.length}</span> encontrados
        </div>
      </div>
      
      {loading ? (
        <div className="flex justify-center items-center h-20">
          <Loader2 className="h-6 w-6 text-primary animate-spin" />
        </div>
      ) : stations.length === 0 ? (
        <div className="text-center py-8">
          <p className="text-gray-500">Nenhum eletroposto encontrado nesta área</p>
        </div>
      ) : (
        <div className="overflow-x-auto py-2">
          <div className="flex px-4 gap-3 min-w-max">
            {stations.map((station) => (
              <div 
                key={station.id} 
                className="w-80 flex-shrink-0"
                onClick={() => onStationClick(station)}
              >
                <ChargingStationCard station={station} />
              </div>
            ))}
          </div>
        </div>
      )}
    </div>
  );
}
