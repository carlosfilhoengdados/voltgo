import { useState } from "react";
import { useLocation } from "wouter";
import { Search, MapPin } from "lucide-react";
import { useGeolocation } from "@/hooks/useGeolocation";
import { useChargingStations } from "@/contexts/ChargingStationsContext";

export default function SearchBar() {
  const [_, setLocation] = useLocation();
  const { location: userLocation } = useGeolocation();
  const { fetchNearbyStations } = useChargingStations();
  
  const handleFocusSearch = () => {
    // Navigate to search page instead of showing search in place
    setLocation("/search");
  };
  
  const handleLocationClick = () => {
    if (userLocation) {
      fetchNearbyStations(userLocation.latitude, userLocation.longitude);
    }
  };

  return (
    <div className="absolute top-4 left-1/2 transform -translate-x-1/2 w-full max-w-md px-4 z-10">
      <div className="bg-white rounded-full shadow-md flex items-center p-1 pl-4">
        <Search className="text-gray-400 mr-2 h-4 w-4" />
        <div 
          className="bg-transparent border-none flex-1 py-2 text-sm cursor-pointer"
          onClick={handleFocusSearch}
        >
          Buscar eletropostos, endereços...
        </div>
        <button 
          className="bg-primary text-white p-2 rounded-full hover:bg-green-500 focus:outline-none transition duration-300"
          onClick={handleLocationClick}
        >
          <MapPin className="h-4 w-4" />
        </button>
      </div>
    </div>
  );
}
