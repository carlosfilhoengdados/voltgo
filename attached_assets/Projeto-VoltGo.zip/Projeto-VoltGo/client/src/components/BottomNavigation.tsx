import { useLocation } from "wouter";
import { MapPin, Search, Ticket, User } from "lucide-react";

export default function BottomNavigation() {
  const [location, setLocation] = useLocation();
  
  const isActive = (path: string) => {
    return location === path;
  };
  
  const navigationItems = [
    { icon: MapPin, label: "Mapa", path: "/map" },
    { icon: Search, label: "Buscar", path: "/search" },
    { icon: Ticket, label: "Pontos", path: "/points" },
    { icon: User, label: "Perfil", path: "/profile" },
  ];

  return (
    <nav className="md:hidden bg-white border-t border-gray-200 fixed bottom-0 left-0 right-0 z-20">
      <div className="flex justify-around">
        {navigationItems.map((item) => (
          <button
            key={item.path}
            className={`flex flex-col items-center justify-center w-1/4 py-2 ${
              isActive(item.path) ? "text-primary" : "text-gray-500"
            }`}
            onClick={() => setLocation(item.path)}
          >
            <item.icon className="text-lg h-5 w-5" />
            <span className="text-xs mt-1">{item.label}</span>
          </button>
        ))}
      </div>
    </nav>
  );
}
