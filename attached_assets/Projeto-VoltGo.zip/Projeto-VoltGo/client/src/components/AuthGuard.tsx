import { ReactNode } from "react";
import { useLocation } from "wouter";
import { useAuth } from "@/contexts/AuthContext";

interface AuthGuardProps {
  children: ReactNode;
  fallback?: ReactNode;
}

export default function AuthGuard({ children, fallback = null }: AuthGuardProps) {
  const { user, loading } = useAuth();
  const [, setLocation] = useLocation();

  // Se estiver carregando, exibir nada
  if (loading) {
    return null;
  }

  // Se não estiver autenticado, redirecionar para o login
  if (!user) {
    // Em uma implementação real, redirecionaríamos para a página de login
    // Para este protótipo, vamos redirecionar para o mapa
    setLocation("/map");
    return fallback;
  }

  // Se estiver autenticado, renderizar o children
  return <>{children}</>;
}