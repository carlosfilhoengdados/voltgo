import { Button } from "@/components/ui/button";
import { MapPin, Filter, Plus } from "lucide-react";

interface ActionButtonsProps {
  onLocationClick: () => void;
  onFilterClick?: () => void;
  onAddClick?: () => void;
}

export default function ActionButtons({ 
  onLocationClick, 
  onFilterClick, 
  onAddClick 
}: ActionButtonsProps) {
  return (
    <div className="flex flex-col gap-2 bg-white p-2 rounded-lg shadow-sm border border-gray-50">
      <div className="text-xs text-center font-medium mb-1 text-gray-600">Ações</div>
      
      {onLocationClick && (
        <Button 
          variant="outline" 
          size="icon" 
          className="rounded-full h-10 w-10 flex items-center justify-center bg-white hover:bg-gray-50 border border-gray-100"
          onClick={onLocationClick}
          title="Centralizar em minha localização"
        >
          <MapPin className="h-5 w-5 text-primary" />
        </Button>
      )}
      
      {onFilterClick && (
        <Button 
          variant="outline" 
          size="icon" 
          className="rounded-full h-10 w-10 flex items-center justify-center bg-white hover:bg-gray-50 border border-gray-100"
          onClick={onFilterClick}
          title="Filtrar eletropostos"
        >
          <Filter className="h-5 w-5 text-primary" />
        </Button>
      )}
      
      {onAddClick && (
        <Button 
          variant="outline" 
          size="icon" 
          className="rounded-full h-10 w-10 flex items-center justify-center bg-white hover:bg-gray-50 border border-gray-100"
          onClick={onAddClick}
          title="Adicionar eletroposto"
        >
          <Plus className="h-5 w-5 text-primary" />
        </Button>
      )}
    </div>
  );
}