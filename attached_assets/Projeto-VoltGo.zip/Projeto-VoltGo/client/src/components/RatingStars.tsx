import { Star } from "lucide-react";

interface RatingStarsProps {
  rating: number;
  max?: number;
  size?: "sm" | "md" | "lg";
  interactive?: boolean;
  onRatingChange?: (rating: number) => void;
}

export default function RatingStars({ 
  rating, 
  max = 5, 
  size = "sm",
  interactive = false,
  onRatingChange
}: RatingStarsProps) {
  const stars = Array.from({ length: max }, (_, i) => i + 1);
  
  // Size classes
  const sizeClasses = {
    sm: "h-3 w-3",
    md: "h-4 w-4",
    lg: "h-5 w-5"
  };
  
  const handleClick = (starIndex: number) => {
    if (interactive && onRatingChange) {
      onRatingChange(starIndex);
    }
  };

  return (
    <div className="flex">
      {stars.map((starIndex) => (
        <div 
          key={starIndex} 
          className={`${interactive ? 'cursor-pointer' : ''}`}
          onClick={() => handleClick(starIndex)}
        >
          <Star 
            className={`${sizeClasses[size]} ${
              starIndex <= rating 
                ? 'text-amber-400 fill-amber-400' 
                : 'text-gray-300'
            }`} 
          />
        </div>
      ))}
    </div>
  );
}
