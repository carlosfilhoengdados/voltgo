import { useState } from "react";
import { X, CheckCircle } from "lucide-react";
import { Button } from "@/components/ui/button";
import { useChargingStations } from "@/contexts/ChargingStationsContext";

interface FilterPanelProps {
  onClose: () => void;
}

interface FilterOption {
  id: string;
  label: string;
  category: string;
}

export default function FilterPanel({ onClose }: FilterPanelProps) {
  const { filters, setFilters } = useChargingStations();
  
  // Define filter options
  const connectorOptions: FilterOption[] = [
    { id: 'Type2', label: 'Tipo 2', category: 'connector' },
    { id: 'CCS', label: 'CCS', category: 'connector' },
    { id: 'CHAdeMO', label: 'CHAdeMO', category: 'connector' },
    { id: 'Tesla', label: 'Tesla', category: 'connector' },
  ];
  
  const powerOptions: FilterOption[] = [
    { id: 'upto22', label: 'Até 22kW', category: 'power' },
    { id: '50plus', label: '50kW+', category: 'power' },
    { id: '100plus', label: '100kW+', category: 'power' },
    { id: '150plus', label: '150kW+', category: 'power' },
  ];
  
  const availabilityOptions: FilterOption[] = [
    { id: 'available', label: 'Disponível agora', category: 'availability' },
    { id: 'all', label: 'Todos', category: 'availability' },
  ];
  
  const servicesOptions: FilterOption[] = [
    { id: 'freeParking', label: 'Estacionamento grátis', category: 'services' },
    { id: 'wifi', label: 'WiFi', category: 'services' },
    { id: 'coffee', label: 'Café', category: 'services' },
    { id: 'shopping', label: 'Shopping', category: 'services' },
  ];
  
  // Initialize selected filters from context
  const [selectedFilters, setSelectedFilters] = useState<{[key: string]: boolean | number}>(
    filters || {
      'Type2': true,
      '50plus': true,
      'available': true,
      'wifi': true,
      'minRating': 3
    }
  );
  
  const toggleFilter = (id: string) => {
    setSelectedFilters(prev => ({
      ...prev,
      [id]: !prev[id]
    }));
  };
  
  const isFilterSelected = (id: string) => {
    return !!selectedFilters[id];
  };
  
  const handleApplyFilters = () => {
    setFilters(selectedFilters);
    onClose();
  };
  
  const handleClearFilters = () => {
    setSelectedFilters({});
  };

  return (
    <div className="absolute top-20 left-1/2 transform -translate-x-1/2 w-full max-w-md px-4 z-10">
      <div className="bg-white rounded-xl shadow-md p-4">
        <div className="flex justify-between items-center mb-4">
          <h3 className="font-heading font-semibold">Filtros</h3>
          <button onClick={onClose} className="text-gray-400 hover:text-gray-600">
            <X className="h-5 w-5" />
          </button>
        </div>
        
        <div className="space-y-4">
          <div>
            <p className="text-sm font-medium mb-2">Tipo de conector</p>
            <div className="flex flex-wrap gap-2">
              {connectorOptions.map((option) => (
                <button
                  key={option.id}
                  className={`text-xs px-3 py-1 rounded-full font-medium flex items-center ${
                    isFilterSelected(option.id)
                      ? 'bg-primary/10 text-primary'
                      : 'bg-gray-100 text-gray-600 hover:bg-gray-200'
                  }`}
                  onClick={() => toggleFilter(option.id)}
                >
                  {isFilterSelected(option.id) && <CheckCircle className="mr-1 h-3 w-3" />}
                  {option.label}
                </button>
              ))}
            </div>
          </div>
          
          <div>
            <p className="text-sm font-medium mb-2">Potência</p>
            <div className="flex flex-wrap gap-2">
              {powerOptions.map((option) => (
                <button
                  key={option.id}
                  className={`text-xs px-3 py-1 rounded-full font-medium flex items-center ${
                    isFilterSelected(option.id)
                      ? 'bg-primary/10 text-primary'
                      : 'bg-gray-100 text-gray-600 hover:bg-gray-200'
                  }`}
                  onClick={() => toggleFilter(option.id)}
                >
                  {isFilterSelected(option.id) && <CheckCircle className="mr-1 h-3 w-3" />}
                  {option.label}
                </button>
              ))}
            </div>
          </div>
          
          <div>
            <p className="text-sm font-medium mb-2">Disponibilidade</p>
            <div className="flex flex-wrap gap-2">
              {availabilityOptions.map((option) => (
                <button
                  key={option.id}
                  className={`text-xs px-3 py-1 rounded-full font-medium flex items-center ${
                    isFilterSelected(option.id)
                      ? 'bg-primary/10 text-primary'
                      : 'bg-gray-100 text-gray-600 hover:bg-gray-200'
                  }`}
                  onClick={() => toggleFilter(option.id)}
                >
                  {isFilterSelected(option.id) && <CheckCircle className="mr-1 h-3 w-3" />}
                  {option.label}
                </button>
              ))}
            </div>
          </div>
          
          <div>
            <p className="text-sm font-medium mb-2">Serviços adicionais</p>
            <div className="flex flex-wrap gap-2">
              {servicesOptions.map((option) => (
                <button
                  key={option.id}
                  className={`text-xs px-3 py-1 rounded-full font-medium flex items-center ${
                    isFilterSelected(option.id)
                      ? 'bg-primary/10 text-primary'
                      : 'bg-gray-100 text-gray-600 hover:bg-gray-200'
                  }`}
                  onClick={() => toggleFilter(option.id)}
                >
                  {isFilterSelected(option.id) && <CheckCircle className="mr-1 h-3 w-3" />}
                  {option.label}
                </button>
              ))}
            </div>
          </div>
          
          <div>
            <p className="text-sm font-medium mb-2">Avaliação mínima</p>
            <div className="flex items-center gap-1">
              {[1, 2, 3, 4, 5].map((rating) => (
                <button 
                  key={rating}
                  className={rating <= (Number(selectedFilters['minRating']) || 3) ? 'text-accent' : 'text-gray-300'}
                  onClick={() => setSelectedFilters(prev => ({ ...prev, minRating: rating }))}
                >
                  <i className="fas fa-star"></i>
                </button>
              ))}
              <span className="text-sm text-gray-600 ml-2">
                ({Number(selectedFilters['minRating']) || 3}+)
              </span>
            </div>
          </div>
        </div>
        
        <div className="mt-4 flex gap-2">
          <Button 
            variant="outline" 
            className="flex-1"
            onClick={handleClearFilters}
          >
            Limpar filtros
          </Button>
          <Button 
            className="flex-1 bg-primary hover:bg-green-500"
            onClick={handleApplyFilters}
          >
            Aplicar filtros
          </Button>
        </div>
      </div>
    </div>
  );
}
