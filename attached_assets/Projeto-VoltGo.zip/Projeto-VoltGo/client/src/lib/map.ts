// Avoid TypeScript errors by declaring the mapboxgl module
declare const mapboxgl: any;

// Mapbox access token - use environment variable or fallback
const MAPBOX_ACCESS_TOKEN = import.meta.env.VITE_MAPBOX_ACCESS_TOKEN || 'pk.eyJ1Ijoidm9sdGdvLWFwcCIsImEiOiJjbHJzd2E5ZjgwNzR0MnF0ZGFkaTQ1N3pvIn0.gvxC-M_PZ7V0M_lx7_3HUA';

let isMapLibraryLoaded = false;

/**
 * Initialize Mapbox by adding script and CSS to document head
 */
export async function initializeMap(): Promise<void> {
  if (isMapLibraryLoaded) return Promise.resolve();
  
  return new Promise((resolve, reject) => {
    try {
      // Add Mapbox CSS
      const mapboxCss = document.createElement('link');
      mapboxCss.rel = 'stylesheet';
      mapboxCss.href = 'https://api.mapbox.com/mapbox-gl-js/v2.15.0/mapbox-gl.css';
      document.head.appendChild(mapboxCss);
      
      // Add Mapbox JS
      const mapboxScript = document.createElement('script');
      mapboxScript.src = 'https://api.mapbox.com/mapbox-gl-js/v2.15.0/mapbox-gl.js';
      mapboxScript.async = true;
      
      mapboxScript.onload = () => {
        // Set access token
        mapboxgl.accessToken = MAPBOX_ACCESS_TOKEN;
        isMapLibraryLoaded = true;
        resolve();
      };
      
      mapboxScript.onerror = (err) => {
        reject(new Error('Failed to load Mapbox GL JS'));
      };
      
      document.head.appendChild(mapboxScript);
    } catch (error) {
      reject(error);
    }
  });
}

/**
 * Create a new map instance
 */
export function createMap(container: HTMLElement, center: [number, number], zoom = 13): mapboxgl.Map {
  return new mapboxgl.Map({
    container,
    style: 'mapbox://styles/mapbox/streets-v11',
    center,
    zoom,
    attributionControl: false
  });
}

/**
 * Create a marker on the map
 */
export function createMarker(
  map: mapboxgl.Map, 
  coordinates: [number, number], 
  id: string, 
  color: string = 'green', 
  pulse: boolean = false
): mapboxgl.Marker {
  // Create a DOM element for the marker
  const markerElement = document.createElement('div');
  markerElement.id = `${id}-marker`;
  markerElement.className = `marker-${color}`;
  
  // Apply styling
  Object.assign(markerElement.style, {
    backgroundColor: getColorForMarker(color),
    width: '24px',
    height: '24px',
    borderRadius: '50%',
    display: 'flex',
    alignItems: 'center',
    justifyContent: 'center',
    color: 'white',
    boxShadow: '0 0 0 rgba(0, 0, 0, 0.2), 0 0 0 rgba(0, 0, 0, 0.2)',
  });
  
  // Add pulse effect
  if (pulse) {
    markerElement.classList.add('pulse');
    Object.assign(markerElement.style, {
      animation: 'pulse 2s infinite',
    });

    // Add keyframes for pulse animation if not already added
    if (!document.getElementById('pulse-animation')) {
      const style = document.createElement('style');
      style.id = 'pulse-animation';
      style.textContent = `
        @keyframes pulse {
          0% {
            box-shadow: 0 0 0 0 rgba(${getColorRgbValues(color)}, 0.4);
          }
          70% {
            box-shadow: 0 0 0 10px rgba(${getColorRgbValues(color)}, 0);
          }
          100% {
            box-shadow: 0 0 0 0 rgba(${getColorRgbValues(color)}, 0);
          }
        }
      `;
      document.head.appendChild(style);
    }
  }
  
  // Add icon inside the marker
  const iconElement = document.createElement('i');
  
  if (id === 'user-location') {
    iconElement.className = 'fas fa-map-marker';
  } else {
    iconElement.className = 'fas fa-bolt';
  }
  
  markerElement.appendChild(iconElement);
  
  // Create and add the marker to the map
  const marker = new mapboxgl.Marker(markerElement)
    .setLngLat(coordinates)
    .addTo(map);
  
  return marker;
}

/**
 * Update the map center
 */
export function updateMapCenter(map: mapboxgl.Map, center: [number, number], zoom?: number): void {
  map.flyTo({
    center,
    zoom: zoom || map.getZoom(),
    essential: true
  });
}

/**
 * Helper function to get appropriate color for markers
 */
function getColorForMarker(color: string): string {
  switch (color) {
    case 'green':
      return '#34d399'; // primary color
    case 'orange':
      return '#f59e0b'; // warning color
    case 'red':
      return '#ef4444'; // danger color
    case 'blue':
      return '#3b82f6'; // secondary color
    default:
      return '#34d399';
  }
}

/**
 * Helper function to get RGB values for pulse animation
 */
function getColorRgbValues(color: string): string {
  switch (color) {
    case 'green':
      return '52, 211, 153';
    case 'orange':
      return '245, 158, 11';
    case 'red':
      return '239, 68, 68';
    case 'blue':
      return '59, 130, 246';
    default:
      return '52, 211, 153';
  }
}
