import { useState, useEffect } from "react";
import { MapContainer, TileLayer, Marker, Popup, useMap } from "react-leaflet";
import "leaflet/dist/leaflet.css";
import Header from "@/components/Header";
import ActionButtons from "@/components/ActionButtons";
import { Loader2, Search, Zap, Map, Moon, Sun } from "lucide-react";
import { useQuery } from "@tanstack/react-query";
import { ChargingStation } from "@shared/schema";
import { useGeolocation } from "@/hooks/useGeolocation";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { cn } from "@/lib/utils";
import L from "leaflet";

// Componente auxiliar para atualizar a visualização do mapa
function ChangeMapView({ center }: { center: [number, number] }) {
  const map = useMap();
  
  useEffect(() => {
    map.setView(center, 13);
  }, [center, map]);
  
  return null;
}

export default function LeafletMapPage() {
  const { location, error: locationError } = useGeolocation();
  const [mapCenter, setMapCenter] = useState<[number, number]>([-23.5505, -46.6333]); // São Paulo por padrão
  const [searchQuery, setSearchQuery] = useState<string>("");
  const [filteredStations, setFilteredStations] = useState<ChargingStation[]>([]);
  const [mapStyle, setMapStyle] = useState<string>("modern");
  
  // Fetch charging stations
  const { data: stations = [], isLoading } = useQuery<ChargingStation[]>({
    queryKey: ['/api/stations'],
  });

  // Inicializar os ícones do Leaflet
  useEffect(() => {
    // Corrigir os ícones padrão do Leaflet que não são carregados automaticamente
    delete (L.Icon.Default.prototype as any)._getIconUrl;
    L.Icon.Default.mergeOptions({
      iconRetinaUrl: "https://unpkg.com/leaflet@1.7.1/dist/images/marker-icon-2x.png",
      iconUrl: "https://unpkg.com/leaflet@1.7.1/dist/images/marker-icon.png",
      shadowUrl: "https://unpkg.com/leaflet@1.7.1/dist/images/marker-shadow.png",
    });
    
    // Inicializar a lista de estações filtradas quando os dados forem carregados
    if (stations.length) {
      setFilteredStations(stations);
    }
  }, [stations]);

  // Atualiza o centro do mapa quando a localização do usuário é obtida
  useEffect(() => {
    if (location) {
      setMapCenter([location.latitude, location.longitude]);
    }
  }, [location]);

  // Filtrar estações com base na pesquisa
  useEffect(() => {
    if (!stations.length) return;
    
    if (!searchQuery.trim()) {
      setFilteredStations(stations);
      return;
    }

    const query = searchQuery.toLowerCase().trim();
    const filtered = stations.filter(station => 
      station.name.toLowerCase().includes(query) || 
      station.address.toLowerCase().includes(query) ||
      station.status.toLowerCase().includes(query)
    );
    
    setFilteredStations(filtered);
  }, [searchQuery, stations]);
  
  // Handle click on location button
  const handleLocationClick = () => {
    if (location) {
      setMapCenter([location.latitude, location.longitude]);
    }
  };
  
  // Criando ícones personalizados para os marcadores
  const createStationIcon = (status: string) => {
    return L.icon({
      iconUrl: status === "Available" 
        ? "https://raw.githubusercontent.com/pointhi/leaflet-color-markers/master/img/marker-icon-2x-green.png"
        : "https://raw.githubusercontent.com/pointhi/leaflet-color-markers/master/img/marker-icon-2x-red.png",
      shadowUrl: "https://cdnjs.cloudflare.com/ajax/libs/leaflet/1.7.1/images/marker-shadow.png",
      iconSize: [25, 41],
      iconAnchor: [12, 41],
      popupAnchor: [1, -34],
      shadowSize: [41, 41]
    });
  };
  
  const userIcon = L.icon({
    iconUrl: "https://raw.githubusercontent.com/pointhi/leaflet-color-markers/master/img/marker-icon-2x-blue.png",
    shadowUrl: "https://cdnjs.cloudflare.com/ajax/libs/leaflet/1.7.1/images/marker-shadow.png",
    iconSize: [25, 41],
    iconAnchor: [12, 41],
    popupAnchor: [1, -34],
    shadowSize: [41, 41]
  });

  return (
    <div className="flex flex-col h-screen">
      <div className="bg-white text-gray-800 p-4 shadow-sm relative overflow-hidden">
        <div className="absolute bottom-0 left-0 right-0 h-20 bg-primary rounded-t-[100%] opacity-90 -z-10 transform translate-y-14"></div>
        <div className="absolute bottom-0 left-0 right-0 h-16 bg-primary rounded-t-[100%] opacity-70 -z-20 transform translate-y-10"></div>
        
        <div className="flex items-center justify-between mb-2 relative z-10">
          <div className="flex items-center">
            <div className="bg-primary h-10 w-10 rounded-lg flex items-center justify-center mr-2">
              <svg width="24" height="24" viewBox="0 0 120 120" fill="none" xmlns="http://www.w3.org/2000/svg" className="text-white">
                <path d="M60 10C32.4 10 10 32.4 10 60C10 87.6 32.4 110 60 110C87.6 110 110 87.6 110 60C110 32.4 87.6 10 60 10ZM80 75C80 77.8 77.8 80 75 80H45C42.2 80 40 77.8 40 75V65H80V75ZM80 55H40V45C40 42.2 42.2 40 45 40H75C77.8 40 80 42.2 80 45V55Z" fill="currentColor"/>
                <rect x="50" y="25" width="20" height="10" fill="currentColor"/>
                <rect x="50" y="85" width="20" height="10" fill="currentColor"/>
              </svg>
            </div>
            <h1 className="text-xl font-bold text-gray-800">VoltGo</h1>
          </div>
          <div className="text-sm bg-white px-3 py-1 rounded-full shadow-sm text-primary font-medium">Mapa de Eletropostos</div>
        </div>
        
        <div className="flex w-full relative z-10">
          <div className="relative w-full">
            <Input
              type="text"
              placeholder="Buscar eletropostos por nome ou endereço..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="w-full pl-10 pr-4 py-2 bg-white text-gray-800 rounded-full shadow-sm border border-gray-100"
            />
            <Search className="absolute left-3 top-2.5 h-4 w-4 text-primary/70" />
          </div>
          <Button 
            variant="outline" 
            size="icon" 
            className="ml-2 rounded-full h-10 w-10 flex items-center justify-center bg-white hover:bg-gray-50 border border-gray-100"
            onClick={() => setSearchQuery("")}
            title="Limpar pesquisa"
          >
            {searchQuery ? (
              <span className="text-xs font-bold text-gray-500">✕</span>
            ) : (
              <Zap className="h-4 w-4 text-primary" />
            )}
          </Button>
        </div>
      </div>
      
      <div className="flex-1 relative">
        {isLoading ? (
          <div className="h-full flex items-center justify-center">
            <Loader2 className="h-10 w-10 text-primary animate-spin" />
            <span className="ml-2 text-gray-600">Carregando estações...</span>
          </div>
        ) : (
          <MapContainer 
            center={mapCenter} 
            zoom={13} 
            style={{ height: "100%", width: "100%" }}
          >
            {mapStyle === "modern" ? (
              <TileLayer
                attribution='&copy; <a href="https://carto.com/">Carto</a>'
                url="https://{s}.basemaps.cartocdn.com/rastertiles/voyager/{z}/{x}/{y}{r}.png"
              />
            ) : mapStyle === "dark" ? (
              <TileLayer
                attribution='&copy; <a href="https://carto.com/">Carto</a>'
                url="https://{s}.basemaps.cartocdn.com/dark_all/{z}/{x}/{y}{r}.png"
              />
            ) : (
              <TileLayer
                attribution='&copy; <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a> contributors'
                url="https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png"
              />
            )}
            
            {/* Marcador para a localização do usuário */}
            {location && (
              <Marker 
                position={[location.latitude, location.longitude]}
                icon={userIcon}
              >
                <Popup>
                  Sua localização
                </Popup>
              </Marker>
            )}
            
            {/* Marcadores para as estações de carregamento */}
            {filteredStations.map(station => (
              <Marker
                key={station.id}
                position={[station.latitude, station.longitude]}
                icon={createStationIcon(station.status)}
              >
                <Popup>
                  <div className="text-sm max-w-[200px]">
                    <h3 className="font-bold text-base">{station.name}</h3>
                    <p className="mt-1">{station.address}</p>
                    <div className="mt-2 grid grid-cols-2 gap-x-2 gap-y-1">
                      <div>
                        <span className="font-semibold">Status:</span> 
                        <span className={station.status === "Available" ? "text-green-600" : "text-red-600"}>
                          {station.status}
                        </span>
                      </div>
                      <div>
                        <span className="font-semibold">Potência:</span> {station.power} kW
                      </div>
                      <div className="col-span-2 flex items-center">
                        <span className="font-semibold mr-1">Avaliação:</span> 
                        <span className="flex items-center">
                          {station.rating} <span className="text-yellow-500 ml-1">★</span>
                        </span>
                      </div>
                    </div>
                  </div>
                </Popup>
              </Marker>
            ))}
            
            {/* Componente que atualiza a visualização do mapa */}
            <ChangeMapView center={mapCenter} />
          </MapContainer>
        )}
      </div>
      
      {/* Controles do mapa */}
      <div className="absolute bottom-20 right-4 z-[1000]">
        <ActionButtons onLocationClick={handleLocationClick} />
      </div>

      {/* Estilos do mapa */}
      <div className="absolute top-24 right-4 z-[1000] flex flex-col gap-2 bg-white p-2 rounded-lg shadow-sm border border-gray-50">
        <div className="text-xs text-center font-medium mb-1 text-gray-600">Estilo do Mapa</div>
        <Button
          variant="outline"
          size="icon"
          className={cn(
            "rounded-full h-8 w-8 border border-gray-100", 
            mapStyle === "standard" ? "bg-primary text-white border-primary" : "bg-white hover:bg-gray-50"
          )}
          onClick={() => setMapStyle("standard")}
          title="Mapa Padrão"
        >
          <Map className="h-4 w-4" />
        </Button>
        <Button
          variant="outline"
          size="icon"
          className={cn(
            "rounded-full h-8 w-8 border border-gray-100",
            mapStyle === "modern" ? "bg-primary text-white border-primary" : "bg-white hover:bg-gray-50"
          )}
          onClick={() => setMapStyle("modern")}
          title="Mapa Moderno"
        >
          <Sun className="h-4 w-4" />
        </Button>
        <Button
          variant="outline"
          size="icon"
          className={cn(
            "rounded-full h-8 w-8 border border-gray-100",
            mapStyle === "dark" ? "bg-primary text-white border-primary" : "bg-white hover:bg-gray-50"
          )}
          onClick={() => setMapStyle("dark")}
          title="Mapa Escuro"
        >
          <Moon className="h-4 w-4" />
        </Button>
      </div>
    </div>
  );
}