import { Link } from "wouter";
import { Button } from "@/components/ui/button";
import { Zap, Map, Users, Info, LogIn } from "lucide-react";
import logoSvg from "@assets/logo.svg";

export default function Home() {
  return (
    <div className="flex flex-col min-h-screen">
      <header className="bg-white text-gray-800 p-6 text-center relative overflow-hidden">
        <div className="absolute bottom-0 left-0 right-0 h-40 bg-primary rounded-t-[100%] opacity-90 -z-10 transform translate-y-24"></div>
        <div className="absolute bottom-0 left-0 right-0 h-32 bg-primary rounded-t-[100%] opacity-70 -z-20 transform translate-y-20"></div>
        
        <div className="flex justify-end mb-4">
          <Link href="/auth">
            <Button variant="outline" size="sm" className="rounded-full px-4 border-gray-200">
              <LogIn className="mr-2 h-4 w-4" />
              Entrar
            </Button>
          </Link>
        </div>
        
        <div className="w-32 h-32 mx-auto mb-4">
          <img src={logoSvg} alt="VoltGo Logo" className="w-full h-full" />
        </div>
        <h1 className="text-3xl font-bold mb-4">VoltGo</h1>
        <p className="text-xl">Encontre pontos de recarga para seu veículo elétrico</p>
        <div className="mt-6">
          <Link href="/map">
            <Button size="lg" className="font-bold bg-primary hover:bg-primary/90">
              <Map className="mr-2 h-5 w-5" />
              Ver Mapa
            </Button>
          </Link>
        </div>
      </header>

      <main className="flex-1 container mx-auto px-4 py-8">
        <section className="mb-12">
          <h2 className="text-2xl font-bold mb-4 text-center">Bem-vindo ao VoltGo</h2>
          <p className="text-center text-gray-600 mb-6">
            O aplicativo perfeito para proprietários de veículos elétricos encontrarem pontos de recarga próximos.
          </p>
          
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mt-8">
            <div className="bg-white p-6 rounded-lg shadow-sm border border-gray-50 flex flex-col items-center text-center">
              <div className="bg-primary/10 p-3 rounded-full mb-4">
                <Map className="h-8 w-8 text-primary" />
              </div>
              <h3 className="text-lg font-bold mb-2">Encontre Eletropostos</h3>
              <p className="text-gray-600">Localize facilmente os pontos de recarga mais próximos de você.</p>
            </div>
            
            <div className="bg-white p-6 rounded-lg shadow-sm border border-gray-50 flex flex-col items-center text-center">
              <div className="bg-primary/10 p-3 rounded-full mb-4">
                <Zap className="h-8 w-8 text-primary" />
              </div>
              <h3 className="text-lg font-bold mb-2">Ganhe Pontos</h3>
              <p className="text-gray-600">Acumule pontos a cada recarga e troque por benefícios exclusivos.</p>
            </div>
            
            <div className="bg-white p-6 rounded-lg shadow-sm border border-gray-50 flex flex-col items-center text-center">
              <div className="bg-primary/10 p-3 rounded-full mb-4">
                <Users className="h-8 w-8 text-primary" />
              </div>
              <h3 className="text-lg font-bold mb-2">Comunidade</h3>
              <p className="text-gray-600">Compartilhe experiências e avaliações com outros usuários.</p>
            </div>
          </div>
        </section>
        
        <section className="mb-8">
          <h2 className="text-2xl font-bold mb-4 text-center">Como Funciona</h2>
          <div className="bg-white p-6 rounded-lg shadow-sm border border-gray-50">
            <ol className="list-decimal pl-6 space-y-4">
              <li className="text-gray-700">
                <span className="font-medium">Localize eletropostos</span>: Use o mapa para encontrar pontos de recarga próximos.
              </li>
              <li className="text-gray-700">
                <span className="font-medium">Verifique disponibilidade</span>: Confira em tempo real se o eletroposto está disponível.
              </li>
              <li className="text-gray-700">
                <span className="font-medium">Recarregue seu veículo</span>: Conecte seu veículo e inicie a recarga.
              </li>
              <li className="text-gray-700">
                <span className="font-medium">Acumule pontos</span>: Ganhe pontos a cada recarga realizada pelo aplicativo.
              </li>
            </ol>
          </div>
        </section>
      </main>

      <footer className="bg-white py-6 px-4 text-center border-t border-gray-100">
        <p className="text-gray-600">
          &copy; 2025 VoltGo. Todos os direitos reservados.
        </p>
        <div className="flex justify-center space-x-4 mt-3">
          <a href="#" className="text-gray-400 hover:text-primary">
            <Info className="h-5 w-5" />
          </a>
          <a href="#" className="text-gray-400 hover:text-primary">
            <Users className="h-5 w-5" />
          </a>
          <a href="#" className="text-gray-400 hover:text-primary">
            <Zap className="h-5 w-5" />
          </a>
        </div>
      </footer>
    </div>
  );
}
