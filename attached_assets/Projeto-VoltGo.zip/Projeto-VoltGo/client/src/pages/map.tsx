import { useState, useEffect } from "react";
import Header from "@/components/Header";
import SearchBar from "@/components/SearchBar";
import FilterPanel from "@/components/FilterPanel";
import ActionButtons from "@/components/ActionButtons";
import ElectropostosPanel from "@/components/ElectropostosPanel";
import DetailModal from "@/components/DetailModal";
import MapView from "@/components/MapView";
import { useChargingStations } from "@/contexts/ChargingStationsContext";
import { useGeolocation } from "@/hooks/useGeolocation";
import { ChargingStation } from "@shared/schema";
import { useToast } from "@/hooks/use-toast";

export default function Map() {
  const [showFilters, setShowFilters] = useState(false);
  const [selectedStation, setSelectedStation] = useState<ChargingStation | null>(null);
  const [showDetailModal, setShowDetailModal] = useState(false);
  const { location, error: locationError } = useGeolocation();
  const { stations, loading, error, fetchNearbyStations } = useChargingStations();
  const { toast } = useToast();

  useEffect(() => {
    if (location && !loading && !error) {
      fetchNearbyStations(location.latitude, location.longitude);
    }
  }, [location, fetchNearbyStations]);

  useEffect(() => {
    if (locationError) {
      toast({
        title: "Erro de localização",
        description: "Não foi possível obter sua localização. Verifique as permissões do navegador.",
        variant: "destructive",
      });
    }
  }, [locationError, toast]);

  const handleMarkerClick = (station: ChargingStation) => {
    setSelectedStation(station);
    setShowDetailModal(true);
  };

  const handleStationCardClick = (station: ChargingStation) => {
    setSelectedStation(station);
    setShowDetailModal(true);
  };

  const toggleFilters = () => {
    setShowFilters(!showFilters);
  };

  return (
    <div className="flex flex-col h-screen bg-light text-dark overflow-hidden">
      <Header onFilterClick={toggleFilters} />
      
      <main className="flex-1 relative overflow-hidden">
        <MapView 
          userLocation={location} 
          stations={stations}
          onMarkerClick={handleMarkerClick}
        />
        
        <SearchBar />
        
        {showFilters && (
          <FilterPanel onClose={() => setShowFilters(false)} />
        )}
        
        <ActionButtons 
          onLocationClick={() => {
            if (location) {
              fetchNearbyStations(location.latitude, location.longitude);
            }
          }}
        />
        
        <ElectropostosPanel 
          stations={stations} 
          loading={loading}
          onStationClick={handleStationCardClick} 
        />
        
        {selectedStation && (
          <DetailModal 
            isOpen={showDetailModal}
            station={selectedStation}
            onClose={() => setShowDetailModal(false)}
          />
        )}
      </main>
    </div>
  );
}
