import { useState, useEffect } from "react";
import { useAuth } from "@/contexts/AuthContext";
import Header from "@/components/Header";
import { useQuery } from "@tanstack/react-query";
import { Card, CardContent } from "@/components/ui/card";
import { Progress } from "@/components/ui/progress";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Badge } from "@/components/ui/badge";
import { ChargingSession, ChargingStation } from "@shared/schema";
import { Loader2, Zap, Gift, Award, Clock, Calendar, MapPin } from "lucide-react";
import { format } from "date-fns";
import { ptBR } from "date-fns/locale";

interface StationDetails {
  [key: number]: ChargingStation;
}

export default function Points() {
  // Sabemos que o usuário está autenticado porque este componente está dentro de AuthGuard
  const { user } = useAuth();
  const [stationDetails, setStationDetails] = useState<StationDetails>({});
  
  // Fetch user's charging sessions
  const { data: sessions, isLoading: sessionsLoading } = useQuery({
    queryKey: [`/api/users/${user?.id}/sessions`],
    enabled: !!user,
  });
  
  // Get station details for each session
  useEffect(() => {
    if (sessions) {
      const fetchStationDetails = async () => {
        const details: StationDetails = {};
        
        for (const session of sessions) {
          if (!stationDetails[session.stationId]) {
            try {
              const response = await fetch(`/api/stations/${session.stationId}`);
              if (response.ok) {
                const station = await response.json();
                details[session.stationId] = station;
              }
            } catch (error) {
              console.error("Failed to fetch station details", error);
            }
          }
        }
        
        setStationDetails(prev => ({ ...prev, ...details }));
      };
      
      fetchStationDetails();
    }
  }, [sessions]);
  
  // Calculate next reward tier
  const calculateNextReward = (points: number) => {
    if (points < 1000) return { name: "Bronze", threshold: 1000, progress: (points / 1000) * 100 };
    if (points < 3000) return { name: "Prata", threshold: 3000, progress: ((points - 1000) / 2000) * 100 };
    if (points < 6000) return { name: "Ouro", threshold: 6000, progress: ((points - 3000) / 3000) * 100 };
    if (points < 10000) return { name: "Platina", threshold: 10000, progress: ((points - 6000) / 4000) * 100 };
    return { name: "Diamante", threshold: points, progress: 100 };
  };
  
  // Get current tier
  const getCurrentTier = (points: number) => {
    if (points < 1000) return "Iniciante";
    if (points < 3000) return "Bronze";
    if (points < 6000) return "Prata";
    if (points < 10000) return "Ouro";
    return "Platina";
  };
  
  const nextReward = user ? calculateNextReward(user.points) : { name: "Bronze", threshold: 1000, progress: 0 };
  const currentTier = user ? getCurrentTier(user.points) : "Iniciante";
  
  // Available vouchers based on points
  const vouchers = [
    { id: 1, name: "10% de desconto na próxima recarga", points: 500, available: user?.points >= 500 },
    { id: 2, name: "Carregamento gratuito (até 10kWh)", points: 2000, available: user?.points >= 2000 },
    { id: 3, name: "50% off em carregamentos rápidos", points: 1200, available: user?.points >= 1200 },
    { id: 4, name: "Café grátis nos postos parceiros", points: 800, available: user?.points >= 800 },
  ];
  
  // Filter completed sessions
  const completedSessions = sessions?.filter((session: ChargingSession) => session.status === "Completed") || [];
  
  // Format date for display
  const formatDate = (date: string) => {
    return format(new Date(date), "dd 'de' MMMM', às' HH:mm", { locale: ptBR });
  };

  return (
    <div className="flex flex-col min-h-screen bg-light">
      <Header title="Seus Pontos" backTo="/map" />
      
      <div className="container mx-auto px-4 py-6 pb-20">
        {!user ? (
          <div className="flex justify-center items-center py-10">
            <Loader2 className="animate-spin h-10 w-10 text-primary" />
          </div>
        ) : (
          <>
            <Card className="mb-6">
              <CardContent className="p-6">
                <div className="flex items-center justify-between mb-4">
                  <div>
                    <h2 className="font-heading text-xl font-semibold">Seus pontos</h2>
                    <p className="text-gray-500">Continue carregando para ganhar recompensas</p>
                  </div>
                  <div className="text-3xl font-bold text-primary flex items-center">
                    <Zap className="mr-1 h-6 w-6" />
                    {user.points}
                  </div>
                </div>
                
                <div className="mb-2 flex justify-between items-center">
                  <span className="text-sm text-gray-600">Nível: {currentTier}</span>
                  <span className="text-sm text-gray-600">
                    Próximo nível: {nextReward.name} ({user.points}/{nextReward.threshold})
                  </span>
                </div>
                
                <Progress value={nextReward.progress} className="h-2 bg-gray-200" />
                
                <div className="mt-4 grid grid-cols-3 gap-2 text-center">
                  <div className="bg-green-50 rounded-lg p-2">
                    <p className="font-medium">{completedSessions.length}</p>
                    <p className="text-xs text-gray-600">Recargas</p>
                  </div>
                  <div className="bg-blue-50 rounded-lg p-2">
                    <p className="font-medium">
                      {completedSessions.reduce((sum: number, session: ChargingSession) => sum + (session.energy || 0), 0).toFixed(1)} kWh
                    </p>
                    <p className="text-xs text-gray-600">Energia total</p>
                  </div>
                  <div className="bg-purple-50 rounded-lg p-2">
                    <p className="font-medium">{vouchers.filter(v => v.available).length}</p>
                    <p className="text-xs text-gray-600">Vouchers</p>
                  </div>
                </div>
              </CardContent>
            </Card>
            
            <Tabs defaultValue="vouchers" className="mb-6">
              <TabsList className="grid grid-cols-2 mb-4">
                <TabsTrigger value="vouchers">Vouchers Disponíveis</TabsTrigger>
                <TabsTrigger value="history">Histórico</TabsTrigger>
              </TabsList>
              
              <TabsContent value="vouchers" className="mt-0">
                <div className="space-y-3">
                  {vouchers.map(voucher => (
                    <Card key={voucher.id} className={`transition-all ${!voucher.available ? 'opacity-50' : ''}`}>
                      <CardContent className="p-4 flex justify-between items-center">
                        <div className="flex items-center">
                          <div className={`p-2 rounded-full ${voucher.available ? 'bg-primary/10 text-primary' : 'bg-gray-100 text-gray-400'} mr-3`}>
                            <Gift className="h-5 w-5" />
                          </div>
                          <div>
                            <p className="font-medium">{voucher.name}</p>
                            <p className="text-xs text-gray-500 mt-1">
                              <Zap className="h-3 w-3 inline mr-1" />
                              {voucher.points} pontos
                            </p>
                          </div>
                        </div>
                        
                        <button 
                          className={`px-4 py-2 rounded-full text-sm font-medium ${
                            voucher.available 
                              ? 'bg-primary text-white' 
                              : 'bg-gray-100 text-gray-400 cursor-not-allowed'
                          }`}
                          disabled={!voucher.available}
                        >
                          {voucher.available ? 'Resgatar' : `Faltam ${voucher.points - user.points} pontos`}
                        </button>
                      </CardContent>
                    </Card>
                  ))}
                </div>
              </TabsContent>
              
              <TabsContent value="history" className="mt-0">
                {sessionsLoading ? (
                  <div className="flex justify-center py-4">
                    <Loader2 className="animate-spin h-6 w-6 text-primary" />
                  </div>
                ) : completedSessions.length === 0 ? (
                  <div className="text-center py-6">
                    <Clock className="h-8 w-8 text-gray-300 mx-auto mb-2" />
                    <p className="text-gray-500">Nenhuma recarga realizada ainda</p>
                  </div>
                ) : (
                  <div className="space-y-3">
                    {completedSessions.map((session: ChargingSession) => {
                      const station = stationDetails[session.stationId];
                      return (
                        <Card key={session.id}>
                          <CardContent className="p-4">
                            <div className="flex justify-between items-start mb-2">
                              <div className="flex-1">
                                <h3 className="font-medium">{station?.name || "Estação desconhecida"}</h3>
                                {station && (
                                  <p className="text-sm text-gray-500 flex items-center mt-1">
                                    <MapPin className="h-3 w-3 mr-1" /> 
                                    {station.address}
                                  </p>
                                )}
                              </div>
                              <Badge className="bg-primary/10 text-primary hover:bg-primary/20 border-0">
                                <Zap className="h-3 w-3 mr-1" />
                                +{session.pointsEarned} pontos
                              </Badge>
                            </div>
                            
                            <div className="grid grid-cols-3 gap-2 text-sm mt-3">
                              <div>
                                <p className="text-gray-500">Data</p>
                                <p className="font-medium">
                                  {session.startTime ? formatDate(session.startTime.toString()) : "N/A"}
                                </p>
                              </div>
                              <div>
                                <p className="text-gray-500">Energia</p>
                                <p className="font-medium">{session.energy} kWh</p>
                              </div>
                              <div>
                                <p className="text-gray-500">Valor</p>
                                <p className="font-medium">R$ {session.cost.toFixed(2)}</p>
                              </div>
                            </div>
                          </CardContent>
                        </Card>
                      );
                    })}
                  </div>
                )}
              </TabsContent>
            </Tabs>
          </>
        )}
      </div>
    </div>
  );
}
