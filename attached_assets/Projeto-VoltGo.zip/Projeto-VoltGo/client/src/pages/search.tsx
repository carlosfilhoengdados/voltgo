import { useState } from "react";
import { useLocation } from "wouter";
import Header from "@/components/Header";
import { useChargingStations } from "@/contexts/ChargingStationsContext";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import ChargingStationCard from "@/components/ChargingStationCard";
import { ChargingStation } from "@shared/schema";
import { Loader2, Search as SearchIcon, X } from "lucide-react";

export default function Search() {
  const [_, setLocation] = useLocation();
  const { stations, loading } = useChargingStations();
  const [searchTerm, setSearchTerm] = useState("");
  const [searchResults, setSearchResults] = useState<ChargingStation[]>([]);
  const [isSearching, setIsSearching] = useState(false);

  const handleSearch = () => {
    if (!searchTerm.trim()) {
      setSearchResults([]);
      return;
    }
    
    setIsSearching(true);
    const term = searchTerm.toLowerCase();
    
    // Search by name, address, and type
    const results = stations.filter(station => 
      station.name.toLowerCase().includes(term) || 
      station.address.toLowerCase().includes(term) ||
      station.stationType.toLowerCase().includes(term)
    );
    
    setSearchResults(results);
    setIsSearching(false);
  };

  const handleClear = () => {
    setSearchTerm("");
    setSearchResults([]);
  };

  const handleStationClick = (station: ChargingStation) => {
    setLocation(`/map`);
    // In a real implementation, we'd pass the station ID to focus on this station
  };

  return (
    <div className="flex flex-col min-h-screen bg-light">
      <Header title="Buscar Eletropostos" backTo="/map" />
      
      <div className="container mx-auto px-4 py-4">
        <div className="flex gap-2 mb-6">
          <div className="relative flex-1">
            <Input
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              placeholder="Buscar por nome, endereço ou tipo..."
              className="pl-10 pr-10"
              onKeyDown={(e) => e.key === 'Enter' && handleSearch()}
            />
            <SearchIcon className="absolute top-1/2 left-3 transform -translate-y-1/2 text-gray-400 h-5 w-5" />
            {searchTerm && (
              <button 
                className="absolute top-1/2 right-3 transform -translate-y-1/2 text-gray-400"
                onClick={handleClear}
              >
                <X className="h-5 w-5" />
              </button>
            )}
          </div>
          <Button onClick={handleSearch} className="bg-primary hover:bg-primaryDark">
            {isSearching ? <Loader2 className="animate-spin h-5 w-5" /> : "Buscar"}
          </Button>
        </div>
        
        {loading ? (
          <div className="flex justify-center py-10">
            <Loader2 className="animate-spin h-10 w-10 text-primary" />
          </div>
        ) : searchResults.length > 0 ? (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
            {searchResults.map(station => (
              <div key={station.id} onClick={() => handleStationClick(station)}>
                <ChargingStationCard station={station} />
              </div>
            ))}
          </div>
        ) : searchTerm ? (
          <div className="text-center py-10">
            <p className="text-gray-600">Nenhum eletroposto encontrado para "{searchTerm}"</p>
          </div>
        ) : (
          <div className="text-center py-10">
            <SearchIcon className="h-10 w-10 text-gray-300 mx-auto mb-4" />
            <p className="text-gray-600">Digite um termo para buscar eletropostos</p>
          </div>
        )}
      </div>
    </div>
  );
}
