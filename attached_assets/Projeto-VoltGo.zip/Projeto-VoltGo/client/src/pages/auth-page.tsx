import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Eye, EyeOff, Facebook, Mail, Twitter } from "lucide-react";
import { Link, useLocation } from "wouter";
import logoSvg from "@assets/logo.svg";
import { useAuth } from "@/contexts/AuthContext";

export default function AuthPage() {
  const [isLogin, setIsLogin] = useState(true);
  const [showPassword, setShowPassword] = useState(false);
  const [username, setUsername] = useState("");
  const [password, setPassword] = useState("");
  const [email, setEmail] = useState("");
  const [name, setName] = useState("");
  const [_, setLocation] = useLocation();
  const { login, register } = useAuth();

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    
    try {
      if (isLogin) {
        await login(username, password);
      } else {
        await register({ username, password, email, name });
      }
      // Redireciona para a página do mapa após login/cadastro bem-sucedido
      setLocation("/map");
    } catch (error) {
      console.error("Erro na autenticação:", error);
    }
  };
  
  return (
    <div className="min-h-screen bg-primary flex flex-col items-center justify-center relative overflow-hidden">
      {/* Ondas decorativas */}
      <div className="absolute bottom-0 left-0 right-0 h-80 bg-primary/80 rounded-t-[150%] -z-10 translate-y-1/4"></div>
      <div className="absolute bottom-0 left-0 right-0 h-60 bg-primary/60 rounded-t-[150%] -z-20 translate-y-1/3"></div>
      
      <div className="max-w-md w-full px-4 pb-10 relative z-10">
        {/* Logo e cabeçalho */}
        <div className="flex flex-col items-center mb-8">
          <div className="h-24 w-24 mb-4">
            <img src={logoSvg} alt="VoltGo Logo" className="w-full h-full" />
          </div>
          <h1 className="text-2xl font-bold text-white mb-2">VoltGo</h1>
          <p className="text-white/90 text-center max-w-xs">
            {isLogin ? 
              "Entre em sua conta para encontrar eletropostos próximos" : 
              "Faça seu cadastro para encontrar eletropostos próximos"}
          </p>
        </div>
        
        {/* Formulário */}
        <div className="bg-white rounded-xl shadow-lg p-6">
          <h2 className="text-xl font-semibold text-center text-gray-800 mb-6">
            {isLogin ? "Entre em sua conta" : "Faça seu cadastro"}
          </h2>
          
          <form className="space-y-4" onSubmit={handleSubmit}>
            {!isLogin && (
              <div className="space-y-4">
                <div>
                  <Input 
                    type="text" 
                    placeholder="Nome completo" 
                    className="w-full border-0 bg-primary/10 placeholder:text-gray-500"
                    value={name}
                    onChange={(e) => setName(e.target.value)}
                    required={!isLogin}
                  />
                </div>
                <div>
                  <Input 
                    type="email" 
                    placeholder="E-mail" 
                    className="w-full border-0 bg-primary/10 placeholder:text-gray-500"
                    value={email}
                    onChange={(e) => setEmail(e.target.value)}
                    required={!isLogin}
                  />
                </div>
              </div>
            )}
            
            <div>
              <Input 
                type="text" 
                placeholder="Nome de usuário" 
                className="w-full border-0 bg-primary/10 placeholder:text-gray-500"
                value={username}
                onChange={(e) => setUsername(e.target.value)}
                required
              />
            </div>
            
            <div className="relative">
              <Input 
                type={showPassword ? "text" : "password"} 
                placeholder="Senha" 
                className="w-full pr-10 border-0 bg-primary/10 placeholder:text-gray-500"
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                required
              />
              <button 
                type="button"
                className="absolute right-3 top-1/2 transform -translate-y-1/2 text-gray-500"
                onClick={() => setShowPassword(!showPassword)}
              >
                {showPassword ? <EyeOff size={18} /> : <Eye size={18} />}
              </button>
            </div>
            
            <Button type="submit" className="w-full bg-primary hover:bg-primary/90 text-white py-6">
              {isLogin ? "Entrar" : "Continuar"}
            </Button>
          </form>
          
          <div className="mt-4">
            <Button 
              variant="outline"
              type="button"
              className="w-full border-primary/20 bg-primary/5 text-primary py-6 hover:bg-primary/10 hover:text-primary"
              onClick={() => setIsLogin(!isLogin)}
            >
              {isLogin ? "Cadastre-se" : "Entrar"}
            </Button>
            
            {isLogin && (
              <Link href="/forgot-password" className="text-sm text-primary block text-center mt-3">
                Esqueceu a senha?
              </Link>
            )}
          </div>
          
          <div className="mt-8 pt-4 border-t border-gray-100">
            <div className="text-xs text-center text-gray-500 mb-4">
              Ou entre com suas redes sociais
            </div>
            <div className="flex justify-center space-x-4">
              <Button variant="outline" size="icon" className="w-10 h-10 rounded-full border-primary/20 bg-primary/5 hover:bg-primary/10">
                <Facebook size={20} className="text-primary" />
              </Button>
              <Button variant="outline" size="icon" className="w-10 h-10 rounded-full border-primary/20 bg-primary/5 hover:bg-primary/10">
                <Twitter size={20} className="text-primary" />
              </Button>
              <Button variant="outline" size="icon" className="w-10 h-10 rounded-full border-primary/20 bg-primary/5 hover:bg-primary/10">
                <Mail size={20} className="text-primary" />
              </Button>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}