import { useState } from "react";
import { useAuth } from "@/contexts/AuthContext";
import Header from "@/components/Header";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Switch } from "@/components/ui/switch";
import { Label } from "@/components/ui/label";
import { useToast } from "@/hooks/use-toast";
import { useQuery } from "@tanstack/react-query";
import { 
  UserCircle, Settings, Star, Heart, Clock, 
  LogOut, Car, Bell, Shield, HelpCircle 
} from "lucide-react";

export default function Profile() {
  // Sabemos que o usuário está autenticado porque este componente está dentro de AuthGuard
  const { user, logout } = useAuth();
  const { toast } = useToast();
  const [isLoggingOut, setIsLoggingOut] = useState(false);
  
  // Fetch user's favorite stations
  const { data: favorites } = useQuery({
    queryKey: [`/api/users/${user?.id}/favorites`],
    enabled: !!user,
  });
  
  // Fetch user's charging sessions
  const { data: sessions } = useQuery({
    queryKey: [`/api/users/${user?.id}/sessions`],
    enabled: !!user,
  });
  
  const handleLogout = async () => {
    setIsLoggingOut(true);
    try {
      await logout();
      toast({
        title: "Logout realizado com sucesso",
        description: "Você foi desconectado da sua conta.",
      });
    } catch (error) {
      toast({
        title: "Erro ao fazer logout",
        description: "Não foi possível desconectar sua conta. Tente novamente.",
        variant: "destructive",
      });
    } finally {
      setIsLoggingOut(false);
    }
  };

  if (!user) {
    return (
      <div className="flex flex-col min-h-screen bg-light">
        <Header title="Perfil" backTo="/map" />
        <div className="container mx-auto px-4 py-10 flex flex-col items-center">
          <UserCircle className="h-20 w-20 text-gray-300 mb-4" />
          <h2 className="text-xl font-medium text-gray-700 mb-2">Faça login para acessar seu perfil</h2>
          <p className="text-gray-500 mb-6 text-center">
            Acesse sua conta para ver seus dados, favoritos e histórico de recargas
          </p>
          <Button className="w-full max-w-xs bg-primary hover:bg-primaryDark">
            Entrar
          </Button>
        </div>
      </div>
    );
  }

  return (
    <div className="flex flex-col min-h-screen bg-light">
      <Header title="Perfil" backTo="/map" />
      
      <div className="container mx-auto px-4 py-6 pb-20">
        <div className="flex items-center mb-6">
          <Avatar className="h-16 w-16 mr-4">
            <AvatarImage src={user.profileImage} alt={user.name} />
            <AvatarFallback>{user.name.charAt(0)}</AvatarFallback>
          </Avatar>
          <div>
            <h2 className="text-xl font-heading font-semibold">{user.name}</h2>
            <p className="text-gray-500">{user.email}</p>
            <div className="flex items-center mt-1 text-primary">
              <Star className="h-4 w-4 fill-current" />
              <span className="text-sm font-medium ml-1">Nível Prata</span>
            </div>
          </div>
        </div>
        
        <div className="grid grid-cols-3 gap-3 mb-6">
          <Card>
            <CardContent className="p-3 text-center">
              <p className="text-lg font-bold">{user.points}</p>
              <p className="text-xs text-gray-500">Pontos</p>
            </CardContent>
          </Card>
          <Card>
            <CardContent className="p-3 text-center">
              <p className="text-lg font-bold">{favorites?.length || 0}</p>
              <p className="text-xs text-gray-500">Favoritos</p>
            </CardContent>
          </Card>
          <Card>
            <CardContent className="p-3 text-center">
              <p className="text-lg font-bold">{sessions?.length || 0}</p>
              <p className="text-xs text-gray-500">Recargas</p>
            </CardContent>
          </Card>
        </div>
        
        <Tabs defaultValue="options" className="mb-6">
          <TabsList className="grid grid-cols-3 mb-4">
            <TabsTrigger value="options">Geral</TabsTrigger>
            <TabsTrigger value="account">Conta</TabsTrigger>
            <TabsTrigger value="vehicles">Veículos</TabsTrigger>
          </TabsList>
          
          <TabsContent value="options" className="mt-0 space-y-4">
            <Card>
              <CardHeader className="py-4 px-6">
                <CardTitle className="text-lg flex items-center">
                  <Bell className="h-5 w-5 mr-2" />
                  Notificações
                </CardTitle>
              </CardHeader>
              <CardContent className="px-6 pb-4 space-y-4">
                <div className="flex items-center justify-between">
                  <Label htmlFor="notifications-new" className="text-sm">
                    Novos eletropostos próximos
                  </Label>
                  <Switch id="notifications-new" defaultChecked />
                </div>
                <div className="flex items-center justify-between">
                  <Label htmlFor="notifications-promos" className="text-sm">
                    Promoções e descontos
                  </Label>
                  <Switch id="notifications-promos" defaultChecked />
                </div>
                <div className="flex items-center justify-between">
                  <Label htmlFor="notifications-status" className="text-sm">
                    Atualizações de status das recargas
                  </Label>
                  <Switch id="notifications-status" defaultChecked />
                </div>
              </CardContent>
            </Card>
            
            <Card>
              <CardHeader className="py-4 px-6">
                <CardTitle className="text-lg flex items-center">
                  <Settings className="h-5 w-5 mr-2" />
                  Configurações
                </CardTitle>
              </CardHeader>
              <CardContent className="px-6 pb-4 space-y-4">
                <div className="flex items-center justify-between">
                  <Label htmlFor="dark-mode" className="text-sm">
                    Modo escuro
                  </Label>
                  <Switch id="dark-mode" />
                </div>
                <div className="flex items-center justify-between">
                  <Label htmlFor="data-save" className="text-sm">
                    Economizar dados do mapa
                  </Label>
                  <Switch id="data-save" />
                </div>
              </CardContent>
            </Card>
          </TabsContent>
          
          <TabsContent value="account" className="mt-0 space-y-4">
            <Card>
              <CardContent className="p-0">
                <ul className="divide-y divide-gray-100">
                  <li className="flex items-center justify-between py-3 px-6 hover:bg-gray-50 cursor-pointer">
                    <div className="flex items-center">
                      <UserCircle className="h-5 w-5 mr-3 text-gray-500" />
                      <span>Editar perfil</span>
                    </div>
                  </li>
                  <li className="flex items-center justify-between py-3 px-6 hover:bg-gray-50 cursor-pointer">
                    <div className="flex items-center">
                      <Shield className="h-5 w-5 mr-3 text-gray-500" />
                      <span>Privacidade e segurança</span>
                    </div>
                  </li>
                  <li className="flex items-center justify-between py-3 px-6 hover:bg-gray-50 cursor-pointer">
                    <div className="flex items-center">
                      <Heart className="h-5 w-5 mr-3 text-gray-500" />
                      <span>Favoritos</span>
                    </div>
                    <span className="text-xs text-gray-500 bg-gray-100 px-2 py-1 rounded-full">
                      {favorites?.length || 0}
                    </span>
                  </li>
                  <li className="flex items-center justify-between py-3 px-6 hover:bg-gray-50 cursor-pointer">
                    <div className="flex items-center">
                      <HelpCircle className="h-5 w-5 mr-3 text-gray-500" />
                      <span>Ajuda e suporte</span>
                    </div>
                  </li>
                  <li 
                    className="flex items-center justify-between py-3 px-6 hover:bg-gray-50 cursor-pointer text-red-500"
                    onClick={handleLogout}
                  >
                    <div className="flex items-center">
                      <LogOut className="h-5 w-5 mr-3" />
                      <span>{isLoggingOut ? "Saindo..." : "Sair da conta"}</span>
                    </div>
                  </li>
                </ul>
              </CardContent>
            </Card>
          </TabsContent>
          
          <TabsContent value="vehicles" className="mt-0">
            <Card className="mb-4">
              <CardHeader className="py-4 px-6">
                <CardTitle className="text-lg flex items-center">
                  <Car className="h-5 w-5 mr-2" />
                  Meus veículos
                </CardTitle>
              </CardHeader>
              <CardContent className="px-6 pb-4">
                <div className="border rounded-lg p-4 mb-4">
                  <div className="flex justify-between items-start">
                    <div>
                      <h3 className="font-medium">Tesla Model 3</h3>
                      <p className="text-sm text-gray-500">2022 - Autonomia: 480 km</p>
                      <div className="mt-2 flex items-center">
                        <span className="text-xs bg-primary/10 text-primary px-2 py-1 rounded-full font-medium">
                          Tipo 2
                        </span>
                        <span className="text-xs bg-primary/10 text-primary px-2 py-1 rounded-full font-medium ml-2">
                          CCS
                        </span>
                        <span className="text-xs bg-primary/10 text-primary px-2 py-1 rounded-full font-medium ml-2">
                          Tesla
                        </span>
                      </div>
                    </div>
                    <Button variant="outline" size="sm">
                      Editar
                    </Button>
                  </div>
                </div>
                
                <Button className="w-full" variant="outline">
                  Adicionar veículo
                </Button>
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>
        
        <div className="text-center text-xs text-gray-400 mt-6">
          <p>VoltGo - Versão 1.0.0</p>
          <p className="mt-1">© 2024 VoltGo. Todos os direitos reservados.</p>
        </div>
      </div>
    </div>
  );
}
