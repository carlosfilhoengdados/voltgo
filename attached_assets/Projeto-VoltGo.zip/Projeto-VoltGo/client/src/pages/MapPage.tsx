import { useState, useEffect } from "react";
import Header from "@/components/Header";
import ActionButtons from "@/components/ActionButtons";
import { Loader2 } from "lucide-react";
import { useQuery } from "@tanstack/react-query";
import { ChargingStation } from "@shared/schema";
import { useGeolocation } from "@/hooks/useGeolocation";
import { createMap, updateMapCenter, createMarker, initializeMap } from "@/lib/map";

export default function MapPage() {
  const [mapLoaded, setMapLoaded] = useState<boolean>(false);
  const [mapInstance, setMapInstance] = useState<mapboxgl.Map | null>(null);
  const [markers, setMarkers] = useState<mapboxgl.Marker[]>([]);
  const { location, error: locationError } = useGeolocation();
  
  // Fetch charging stations
  const { data: stations = [], isLoading } = useQuery<ChargingStation[]>({
    queryKey: ['/api/stations'],
  });

  // Initialize map when component mounts
  useEffect(() => {
    const setupMap = async () => {
      try {
        await initializeMap();
        setMapLoaded(true);
      } catch (err) {
        console.error("Failed to initialize map:", err);
      }
    };
    
    setupMap();
    
    return () => {
      // Clean up map instance when component unmounts
      if (mapInstance) {
        mapInstance.remove();
      }
    };
  }, []);
  
  // Create map when mapLoaded becomes true
  useEffect(() => {
    if (!mapLoaded) return;
    
    const mapContainer = document.getElementById('map-container');
    if (!mapContainer) return;
    
    // Default location (São Paulo)
    const defaultLocation: [number, number] = [-46.6333, -23.5505];
    
    // Create map with default location
    const map = createMap(mapContainer, defaultLocation);
    setMapInstance(map);
    
    return () => {
      // Clean up markers when map changes
      markers.forEach(marker => marker.remove());
      setMarkers([]);
    };
  }, [mapLoaded]);
  
  // Update map center when user location is obtained
  useEffect(() => {
    if (!mapInstance || !location) return;
    
    const { latitude, longitude } = location;
    updateMapCenter(mapInstance, [longitude, latitude], 13);
    
    // Create a marker for user location
    const userMarker = createMarker(
      mapInstance,
      [longitude, latitude],
      "Sua localização",
      "blue"
    );
    
    // Add marker to the list for cleanup
    setMarkers(prev => [...prev, userMarker]);
  }, [mapInstance, location]);
  
  // Add charging station markers to the map
  useEffect(() => {
    if (!mapInstance || !stations.length) return;
    
    // Remove existing station markers
    markers.forEach(marker => marker.remove());
    
    // Create new markers for stations
    const newMarkers = stations.map(station => {
      return createMarker(
        mapInstance,
        [station.longitude, station.latitude],
        station.name,
        station.status === "Available" ? "green" : "red"
      );
    });
    
    // Create a marker for user location if available
    let allMarkers = [...newMarkers];
    if (location) {
      const userMarker = createMarker(
        mapInstance,
        [location.longitude, location.latitude],
        "Sua localização",
        "blue"
      );
      allMarkers = [...allMarkers, userMarker];
    }
    
    setMarkers(allMarkers);
  }, [mapInstance, stations, location]);
  
  // Handle click on location button
  const handleLocationClick = () => {
    if (!location) return;
    
    if (mapInstance) {
      updateMapCenter(mapInstance, [location.longitude, location.latitude], 14);
    }
  };
  
  return (
    <div className="flex flex-col h-screen">
      <Header title="Mapa" onFilterClick={() => {}} />
      
      <div id="map-container" className="flex-1 bg-gray-100">
        {(!mapLoaded || isLoading) && (
          <div className="h-full flex items-center justify-center">
            <Loader2 className="h-10 w-10 text-primary animate-spin" />
            <span className="ml-2 text-gray-600">Carregando mapa...</span>
          </div>
        )}
      </div>
      
      <div className="absolute bottom-20 right-4">
        <ActionButtons onLocationClick={handleLocationClick} />
      </div>
    </div>
  );
}