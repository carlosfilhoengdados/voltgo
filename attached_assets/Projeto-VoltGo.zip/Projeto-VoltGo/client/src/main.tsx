import { createRoot } from "react-dom/client";
import "./index.css";
import { QueryClientProvider } from "@tanstack/react-query";
import { queryClient } from "./lib/queryClient";
import { Toaster } from "@/components/ui/toaster";

// Temporariamente importando componentes diretamente
import { Switch, Route, useLocation } from "wouter";
import NotFound from "@/pages/not-found";
import Home from "@/pages/home";
import LeafletMapPage from "@/pages/LeafletMapPage";
import AuthPage from "@/pages/auth-page";
import { useEffect, Suspense } from "react";
import BottomNavigation from "@/components/BottomNavigation";
import { AuthProvider } from "./contexts/AuthContext";
import { ChargingStationsProvider } from "./contexts/ChargingStationsContext";

// Página temporária para mostrar enquanto resolvemos os problemas de contexto
function SimplePage({ title }: { title: string }) {
  return (
    <div className="flex flex-col min-h-screen bg-light">
      <div className="container mx-auto px-4 py-10">
        <h1 className="text-2xl font-bold text-center mb-6">{title}</h1>
        <p className="text-center text-gray-600">
          Estamos construindo esta página. Em breve estará disponível.
        </p>
      </div>
    </div>
  );
}

// Componente simplificado para renderizar a aplicação
function MainApp() {
  const [location] = useLocation();
  
  // Show or hide bottom navigation based on route
  const showBottomNav = !location.includes("/auth") && !location.includes("/login") && !location.includes("/register");

  useEffect(() => {
    // Title based on route
    let title = "VoltGo - Encontre Eletropostos";
    
    if (location === "/points") {
      title = "VoltGo - Seus Pontos";
    } else if (location === "/profile") {
      title = "VoltGo - Seu Perfil";
    } else if (location === "/search") {
      title = "VoltGo - Buscar Eletropostos";
    }
    
    document.title = title;
  }, [location]);

  return (
    <>
      <Switch>
        <Route path="/" component={Home} />
        <Route path="/map" component={LeafletMapPage} />
        <Route path="/auth" component={AuthPage} />
        <Route path="/search">
          <SimplePage title="Buscar Eletropostos" />
        </Route>
        <Route path="/profile">
          <SimplePage title="Perfil do Usuário" />
        </Route>
        <Route path="/points">
          <SimplePage title="Seus Pontos" />
        </Route>
        <Route>
          <NotFound />
        </Route>
      </Switch>
      
      {showBottomNav && <BottomNavigation />}
    </>
  );
}

createRoot(document.getElementById("root")!).render(
  <QueryClientProvider client={queryClient}>
    <AuthProvider>
      <ChargingStationsProvider>
        <Suspense fallback={<div>Carregando...</div>}>
          <MainApp />
          <Toaster />
        </Suspense>
      </ChargingStationsProvider>
    </AuthProvider>
  </QueryClientProvider>
);
