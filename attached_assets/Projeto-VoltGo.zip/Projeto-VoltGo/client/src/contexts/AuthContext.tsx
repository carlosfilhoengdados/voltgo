import { createContext, useContext, ReactNode, useState, useEffect } from "react";
import { User } from "@shared/schema";
import { apiRequest } from "@/lib/queryClient";

interface AuthContextType {
  user: User | null;
  loading: boolean;
  error: string | null;
  login: (username: string, password: string) => Promise<void>;
  register: (userData: { username: string; password: string; email: string; name: string; }) => Promise<void>;
  logout: () => Promise<void>;
}

const AuthContext = createContext<AuthContextType | undefined>(undefined);

export function AuthProvider({ children }: { children: ReactNode }) {
  const [user, setUser] = useState<User | null>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  // Check if user is logged in on initial load
  useEffect(() => {
    const checkLoggedInUser = async () => {
      try {
        // In a real implementation, we'd check a session cookie or token
        // For this prototype, we'll simulate a logged in user
        
        // Simulate a delay to mimic a real API call
        await new Promise(resolve => setTimeout(resolve, 500));
        
        // Set a mock user for demo purposes
        setUser({
          id: 1,
          username: "usuario_teste",
          password: "", // We don't store the password in client state
          name: "Usuário Teste",
          email: "usuario@teste.com",
          points: 1580,
          profileImage: "https://randomuser.me/api/portraits/men/54.jpg"
        });
        
      } catch (err) {
        console.error("Failed to check logged in user:", err);
        setError("Falha ao verificar usuário logado");
      } finally {
        setLoading(false);
      }
    };

    checkLoggedInUser();
  }, []);

  // Login function
  const login = async (username: string, password: string) => {
    setLoading(true);
    setError(null);
    
    try {
      const response = await apiRequest('POST', '/api/auth/login', { username, password });
      const userData = await response.json();
      
      setUser(userData);
      console.log(`Login bem-sucedido: Bem-vindo de volta, ${userData.name}!`);
    } catch (err) {
      console.error("Login failed:", err);
      setError("Falha no login. Verifique suas credenciais.");
      console.log("Falha no login: Nome de usuário ou senha incorretos");
      
      throw err;
    } finally {
      setLoading(false);
    }
  };

  // Register function
  const register = async (userData: { username: string; password: string; email: string; name: string; }) => {
    setLoading(true);
    setError(null);
    
    try {
      const response = await apiRequest('POST', '/api/auth/register', userData);
      const newUser = await response.json();
      
      setUser(newUser);
      console.log("Registro bem-sucedido: Sua conta foi criada com sucesso!");
    } catch (err) {
      console.error("Registration failed:", err);
      setError("Falha no registro. Tente novamente.");
      console.log("Falha no registro: Não foi possível criar sua conta. Tente novamente.");
      
      throw err;
    } finally {
      setLoading(false);
    }
  };

  // Logout function
  const logout = async () => {
    setLoading(true);
    
    try {
      // In a real implementation, we'd invalidate the session on the server
      // For this prototype, we'll just clear the user state
      await new Promise(resolve => setTimeout(resolve, 500));
      
      setUser(null);
    } catch (err) {
      console.error("Logout failed:", err);
      setError("Falha ao fazer logout");
      console.log("Falha ao fazer logout: Não foi possível sair da sua conta");
      
      throw err;
    } finally {
      setLoading(false);
    }
  };

  return (
    <AuthContext.Provider value={{ user, loading, error, login, register, logout }}>
      {children}
    </AuthContext.Provider>
  );
}

export function useAuth() {
  const context = useContext(AuthContext);
  
  // Em vez de lançar um erro, retornamos um valor padrão
  if (context === undefined) {
    console.warn("useAuth está sendo usado fora de um AuthProvider, usando valores padrão");
    return {
      user: null,
      loading: false,
      error: null,
      login: async () => console.warn("AuthProvider não disponível"),
      register: async () => console.warn("AuthProvider não disponível"),
      logout: async () => console.warn("AuthProvider não disponível"),
    };
  }
  
  return context;
}
