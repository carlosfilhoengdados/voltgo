import { createContext, useContext, ReactNode, useState, useCallback } from "react";
import { ChargingStation } from "@shared/schema";
import { useQuery, useQueryClient } from "@tanstack/react-query";

interface ChargingStationsContextType {
  stations: ChargingStation[];
  loading: boolean;
  error: Error | null;
  fetchNearbyStations: (latitude: number, longitude: number, radius?: number) => void;
  filters: {[key: string]: boolean | number} | null;
  setFilters: (filters: {[key: string]: boolean | number}) => void;
}

const ChargingStationsContext = createContext<ChargingStationsContextType | undefined>(undefined);

export function ChargingStationsProvider({ children }: { children: ReactNode }) {
  const [currentCoordinates, setCurrentCoordinates] = useState<{
    latitude: number;
    longitude: number;
    radius?: number;
  } | null>(null);
  
  const [filters, setFilters] = useState<{[key: string]: boolean | number} | null>({
    'Type2': true,
    '50plus': true,
    'available': true,
    'wifi': true,
    'minRating': 3
  });
  
  const queryClient = useQueryClient();
  
  // Query for fetching charging stations
  const {
    data: stations = [],
    isLoading: loading,
    error,
  } = useQuery<ChargingStation[], Error>({
    queryKey: currentCoordinates 
      ? [`/api/stations/nearby?latitude=${currentCoordinates.latitude}&longitude=${currentCoordinates.longitude}&radius=${currentCoordinates.radius || 5}`]
      : ['/api/stations'],
    enabled: true, // Always enabled
  });
  
  // Function to fetch nearby stations
  const fetchNearbyStations = useCallback((latitude: number, longitude: number, radius: number = 5) => {
    setCurrentCoordinates({ latitude, longitude, radius });
    
    // Invalidate the query to force a refetch
    queryClient.invalidateQueries({ 
      queryKey: [`/api/stations/nearby?latitude=${latitude}&longitude=${longitude}&radius=${radius}`] 
    });
  }, [queryClient]);
  
  // Filter stations based on selected filters
  const filteredStations = useCallback(() => {
    if (!filters) return stations;
    
    return stations.filter(station => {
      // Filter by connector type
      // This would need to fetch connector info for each station
      
      // Filter by power
      if (filters['upto22'] && station.power <= 22) return true;
      if (filters['50plus'] && station.power >= 50) return true;
      if (filters['100plus'] && station.power >= 100) return true;
      if (filters['150plus'] && station.power >= 150) return true;
      
      // Filter by availability
      if (filters['available'] && station.status !== 'Available') return false;
      
      // Filter by services
      if (filters['wifi'] && !station.hasWifi) return false;
      if (filters['coffee'] && !station.hasCoffee) return false;
      if (filters['freeParking'] && !station.hasFreeParking) return false;
      if (filters['shopping'] && !station.hasShops) return false;
      
      // Filter by rating
      const minRating = filters['minRating'] !== undefined ? Number(filters['minRating']) : 0;
      if (station.rating < minRating) return false;
      
      return true;
    });
  }, [stations, filters]);
  
  const value = {
    stations: filteredStations(),
    loading,
    error,
    fetchNearbyStations,
    filters,
    setFilters: (newFilters: {[key: string]: boolean | number}) => setFilters(newFilters),
  };

  return (
    <ChargingStationsContext.Provider value={value}>
      {children}
    </ChargingStationsContext.Provider>
  );
}

export function useChargingStations() {
  const context = useContext(ChargingStationsContext);
  
  if (context === undefined) {
    console.warn("useChargingStations está sendo usado fora de um ChargingStationsProvider, usando valores padrão");
    return {
      stations: [],
      loading: false,
      error: null,
      fetchNearbyStations: () => console.warn("ChargingStationsProvider não disponível"),
      filters: null,
      setFilters: () => console.warn("ChargingStationsProvider não disponível"),
    };
  }
  
  return context;
}
