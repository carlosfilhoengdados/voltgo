import { Switch, Route, useLocation } from "wouter";
import NotFound from "@/pages/not-found";
import Home from "@/pages/home";
import Map from "@/pages/map";
import Search from "@/pages/search";
import Points from "@/pages/points";
import Profile from "@/pages/profile";
import BottomNavigation from "@/components/BottomNavigation";
import { useEffect, Suspense } from "react";
import AuthGuard from "@/components/AuthGuard";
import { useAuth } from "@/contexts/AuthContext";

// Componente principal da aplicação
function App() {
  return (
    <Suspense fallback={<div>Carregando...</div>}>
      <AppContent />
    </Suspense>
  );
}

// Conteúdo principal da aplicação
function AppContent() {
  const [location] = useLocation();
  const { loading } = useAuth();
  
  // Show or hide bottom navigation based on route
  const showBottomNav = !location.includes("/login") && !location.includes("/register");

  useEffect(() => {
    if (loading) return;
    
    // Title based on route
    let title = "VoltGo - Encontre Eletropostos";
    
    if (location === "/points") {
      title = "VoltGo - Seus Pontos";
    } else if (location === "/profile") {
      title = "VoltGo - Seu Perfil";
    } else if (location === "/search") {
      title = "VoltGo - Buscar Eletropostos";
    }
    
    document.title = title;
  }, [location, loading]);

  if (loading) {
    return <div>Carregando autenticação...</div>;
  }

  return (
    <>
      <Switch>
        <Route path="/" component={Home} />
        <Route path="/map" component={Map} />
        <Route path="/search" component={Search} />
        <Route path="/points">
          <AuthGuard>
            <Points />
          </AuthGuard>
        </Route>
        <Route path="/profile">
          <AuthGuard>
            <Profile />
          </AuthGuard>
        </Route>
        <Route component={NotFound} />
      </Switch>
      
      {showBottomNav && <BottomNavigation />}
    </>
  );
}

export default App;
