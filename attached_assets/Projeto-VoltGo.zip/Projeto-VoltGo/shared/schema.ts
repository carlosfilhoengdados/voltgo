import { pgTable, text, serial, integer, boolean, timestamp, pgEnum, doublePrecision } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

// User schema
export const users = pgTable("users", {
  id: serial("id").primaryKey(),
  username: text("username").notNull().unique(),
  password: text("password").notNull(),
  name: text("name").notNull(),
  email: text("email").notNull().unique(),
  points: integer("points").default(0).notNull(),
  profileImage: text("profileImage"),
});

export const insertUserSchema = createInsertSchema(users).omit({
  id: true,
  points: true,
});

// Connector type enum
export const connectorTypeEnum = pgEnum("connector_type", [
  "Type2",
  "CCS",
  "CHAdeMO",
  "Tesla",
]);

// Status enum
export const statusEnum = pgEnum("status", [
  "Available",
  "Occupied",
  "Unavailable",
]);

// Charging station schema
export const chargingStations = pgTable("chargingStations", {
  id: serial("id").primaryKey(),
  name: text("name").notNull(),
  address: text("address").notNull(),
  latitude: doublePrecision("latitude").notNull(),
  longitude: doublePrecision("longitude").notNull(),
  image: text("image"),
  rating: doublePrecision("rating").default(0).notNull(),
  reviewCount: integer("reviewCount").default(0).notNull(),
  stationType: text("stationType").notNull(), // Shopping, Supercarregador, Café, Corporativo, etc.
  power: integer("power").notNull(), // kW
  price: doublePrecision("price").default(0), // Price per kWh
  totalSpots: integer("totalSpots").default(1).notNull(),
  availableSpots: integer("availableSpots").default(1).notNull(),
  status: text("status").notNull().default("Available"),
  pointsReward: integer("pointsReward").default(0).notNull(),
  openingTime: text("openingTime").default("24h"),
  hasCoffee: boolean("hasCoffee").default(false),
  hasWifi: boolean("hasWifi").default(false),
  hasRestrooms: boolean("hasRestrooms").default(false),
  hasShops: boolean("hasShops").default(false),
  hasRestaurants: boolean("hasRestaurants").default(false),
  hasFreeParking: boolean("hasFreeParking").default(false),
});

export const insertChargingStationSchema = createInsertSchema(chargingStations).omit({
  id: true,
  rating: true,
  reviewCount: true,
});

// Connector schema
export const connectors = pgTable("connectors", {
  id: serial("id").primaryKey(),
  stationId: integer("stationId").notNull(), // Foreign key to chargingStations
  type: text("type").notNull(), // Type2, CCS, CHAdeMO, Tesla
  count: integer("count").default(1).notNull(),
});

export const insertConnectorSchema = createInsertSchema(connectors).omit({
  id: true,
});

// Review schema
export const reviews = pgTable("reviews", {
  id: serial("id").primaryKey(),
  userId: integer("userId").notNull(), // Foreign key to users
  stationId: integer("stationId").notNull(), // Foreign key to chargingStations
  rating: integer("rating").notNull(),
  comment: text("comment"),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
});

export const insertReviewSchema = createInsertSchema(reviews).omit({
  id: true,
  createdAt: true,
});

// Charging session schema
export const chargingSessions = pgTable("chargingSessions", {
  id: serial("id").primaryKey(),
  userId: integer("userId").notNull(), // Foreign key to users
  stationId: integer("stationId").notNull(), // Foreign key to chargingStations
  startTime: timestamp("startTime").defaultNow().notNull(),
  endTime: timestamp("endTime"),
  energy: doublePrecision("energy").default(0), // kWh
  cost: doublePrecision("cost").default(0), // Total cost
  pointsEarned: integer("pointsEarned").default(0),
  status: text("status").default("Active").notNull(), // Active, Completed, Cancelled
});

export const insertChargingSessionSchema = createInsertSchema(chargingSessions).omit({
  id: true,
  startTime: true,
  endTime: true,
});

// Favorite stations schema
export const favoriteStations = pgTable("favoriteStations", {
  id: serial("id").primaryKey(),
  userId: integer("userId").notNull(), // Foreign key to users
  stationId: integer("stationId").notNull(), // Foreign key to chargingStations
});

export const insertFavoriteStationSchema = createInsertSchema(favoriteStations).omit({
  id: true,
});

// Export types
export type User = typeof users.$inferSelect;
export type InsertUser = z.infer<typeof insertUserSchema>;

export type ChargingStation = typeof chargingStations.$inferSelect;
export type InsertChargingStation = z.infer<typeof insertChargingStationSchema>;

export type Connector = typeof connectors.$inferSelect;
export type InsertConnector = z.infer<typeof insertConnectorSchema>;

export type Review = typeof reviews.$inferSelect;
export type InsertReview = z.infer<typeof insertReviewSchema>;

export type ChargingSession = typeof chargingSessions.$inferSelect;
export type InsertChargingSession = z.infer<typeof insertChargingSessionSchema>;

export type FavoriteStation = typeof favoriteStations.$inferSelect;
export type InsertFavoriteStation = z.infer<typeof insertFavoriteStationSchema>;
